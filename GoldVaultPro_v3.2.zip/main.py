"""
╔═══════════════════════════════════════════════════════════════╗
║  GOLDVAULT PRO — Investment Manager Bot v3.0                 ║
║  Compatible with ALL MT5 Brokers                             ║
║  XAUUSD · BTCUSD                                            ║
║                                                              ║
║  Usage:                                                      ║
║    python main.py                                            ║
║    python main.py --config path/to/settings.yaml             ║
╚═══════════════════════════════════════════════════════════════╝
"""
import argparse
import os
import sys
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description="GoldVault Pro Trading Bot")
    parser.add_argument(
        "--config", "-c",
        default=None,
        help="Path to settings.yaml (default: config/settings.yaml)",
    )
    args = parser.parse_args()

    # Ensure state directory exists
    Path("state").mkdir(exist_ok=True)

    # Import and start engine
    from core.engine import Engine
    engine = Engine(config_path=args.config)
    engine.start()


if __name__ == "__main__":
    main()
