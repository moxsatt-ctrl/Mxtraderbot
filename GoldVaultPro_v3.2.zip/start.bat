@echo off
title GoldVault Pro — Investment Manager Bot
echo ============================================================
echo   GOLDVAULT PRO v2.0 — Starting...
echo ============================================================
echo.

REM Check Python
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python not found. Install Python 3.10+
    pause
    exit /b 1
)

REM Install dependencies if needed
if not exist ".venv" (
    echo [SETUP] Creating virtual environment...
    python -m venv .venv
    call .venv\Scripts\activate
    pip install -r requirements.txt
) else (
    call .venv\Scripts\activate
)

REM Create state directory
if not exist "state" mkdir state

echo.
echo [START] Launching GoldVault Pro...
echo [INFO]  Press Ctrl+C to stop gracefully
echo.

python main.py %*

echo.
echo [STOP] GoldVault Pro has stopped.
pause
