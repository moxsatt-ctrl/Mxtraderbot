"""GoldVault Pro — Core Package"""
__version__ = "3.0.0"
__all__ = [
    "config", "engine", "execution", "indicators", "journal",
    "market", "mt5", "position_manager", "risk", "strategy",
    "symbols", "types",
]
