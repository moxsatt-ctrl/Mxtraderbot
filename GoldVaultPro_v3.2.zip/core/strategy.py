"""
GoldVault Pro v3.0 — Strategy Engine
5 strategies with per-strategy scoring, adaptive thresholds, and campaign awareness.

Strategies:
  1. TREND_CONTINUATION  — ride existing trend, enter on pullback or continuation
  2. BREAKOUT_EXPANSION   — capture fresh breakouts with volume confirmation
  3. PULLBACK_TO_TREND    — enter at better price after pullback, higher TF trend intact
  4. CRT_SCALP            — fast mean-reversion in range (XAU primary)
  5. MANUAL_STYLE         — replicates momentum acceleration pattern from manual trades
"""
from __future__ import annotations
import logging
from typing import List, Optional

from .config import Config
from .types import (
    Action, CampaignState, MarketContext, Regime,
    SetupType, Side, Signal, SymbolSpec,
)

log = logging.getLogger("gvpro.strategy")


class StrategyEngine:
    def __init__(self, cfg: Config):
        self.cfg = cfg

    def evaluate(self, ctx: MarketContext, spec: SymbolSpec,
                 campaign: Optional[CampaignState] = None) -> Signal:
        """
        Evaluate all enabled strategies. Return the best signal or WAIT.
        campaign: existing open campaign for this symbol+side — enables ADD logic.
        """
        # ── Gate: spread too wide ────────────────────────
        max_spread = self.cfg.max_spread_pct(spec.requested)
        if ctx.spread_pct_of_atr > max_spread:
            return Signal(ctx.symbol, Action.WAIT,
                          reasons=[f"spread_wide({ctx.spread_pct_of_atr:.1f}%>{max_spread}%)"])

        candidates: List[Signal] = []
        for fn in [self._trend_continuation, self._breakout_expansion,
                   self._pullback_to_trend, self._crt_scalp, self._manual_style]:
            sig = fn(ctx, spec)
            if sig is not None:
                candidates.append(sig)

        if not candidates:
            return Signal(ctx.symbol, Action.WAIT, reasons=["no_strategy_match"])

        best = max(candidates, key=lambda s: s.score)

        # ── Gate: cost-to-TP spread ratio ────────────────
        tp_dist = abs(best.tp_price - best.entry_price)
        if tp_dist > 0:
            spread_price = ctx.ask - ctx.bid
            ratio = spread_price / tp_dist
            max_ratio = self.cfg.spread_to_tp_ratio(spec.requested)
            if ratio > max_ratio:
                return Signal(ctx.symbol, Action.WAIT,
                              reasons=[f"cost_to_tp({ratio:.2f}>{max_ratio:.2f})"])

        # ── Campaign add: convert to ADD if same side ─────
        if campaign and campaign.count > 0 and best.side == campaign.side:
            best.action = Action.ADD
            best.is_add = True

        return best

    # ═════════════════════════════════════════════════════════
    #  1. TREND CONTINUATION
    # ═════════════════════════════════════════════════════════

    def _trend_continuation(self, ctx: MarketContext, spec: SymbolSpec) -> Optional[Signal]:
        tcfg = self.cfg.trend_cfg(spec.requested)
        if not tcfg.get("enabled", True):
            return None

        min_adx = float(tcfg.get("min_adx", 20))
        rsi_max = float(tcfg.get("rsi_max", 70))
        rsi_min = float(tcfg.get("rsi_min", 30))
        sl_mult = float(tcfg.get("sl_atr_mult", 1.8))
        min_score = self.cfg.min_score_trend_continuation
        min_rr = self.cfg.min_rr_trend

        e, t, b = ctx.entry_tf, ctx.trend_tf, ctx.bias_tf
        regime = ctx.regime

        if regime not in (Regime.TREND_UP, Regime.TREND_DOWN, Regime.BREAKOUT):
            return None
        if e.adx < min_adx:
            return None

        score = 0.0
        reasons: List[str] = []
        side: Optional[Side] = None

        if regime in (Regime.TREND_UP, Regime.BREAKOUT) and e.ema_fast > e.ema_slow:
            side = Side.BUY
            # EMA alignment scores
            if e.ema_fast > e.ema_slow > e.ema_trend:
                score += 22; reasons.append("ema3_align")
            elif e.ema_fast > e.ema_slow:
                score += 12; reasons.append("ema2_align")
            # MACD bull
            if e.macd_hist > 0:
                score += 15; reasons.append("macd_bull")
            if e.macd_hist > e.macd_signal and e.macd_hist > 0:
                score += 5; reasons.append("macd_accel")
            # RSI: healthy zone, not overextended
            if rsi_min < e.rsi < 60:
                score += 10; reasons.append("rsi_healthy")
            elif e.rsi >= rsi_max:
                return None  # overextended, skip
            # H1 confirmation
            if t.ema_fast > t.ema_slow:
                score += 12; reasons.append("h1_bull")
            # H4 bias
            if b.ema_bias > 0 and e.ema_fast > b.ema_bias:
                score += 8; reasons.append("h4_bull")
            # Pullback bonus: price near EMA slow
            if e.ema_slow > 0:
                dist_atr = abs(ctx.ask - e.ema_slow) / max(ctx.atr_value, 1e-10)
                if dist_atr < 0.8:
                    score += 14; reasons.append("pullback_zone")
                elif dist_atr < 1.5:
                    score += 6; reasons.append("near_ema")
            # DI confirmation
            if e.plus_di > e.minus_di:
                score += 8; reasons.append("di_bull")
            # Momentum bonus
            if ctx.entry_tf.momentum > 0.2:
                score += 8; reasons.append("momentum_bull")

        elif regime == Regime.TREND_DOWN and e.ema_fast < e.ema_slow:
            side = Side.SELL
            if e.ema_fast < e.ema_slow < e.ema_trend:
                score += 22; reasons.append("ema3_align")
            elif e.ema_fast < e.ema_slow:
                score += 12; reasons.append("ema2_align")
            if e.macd_hist < 0:
                score += 15; reasons.append("macd_bear")
            if e.macd_hist < e.macd_signal and e.macd_hist < 0:
                score += 5; reasons.append("macd_accel")
            if 40 < e.rsi < (100 - rsi_min):
                score += 10; reasons.append("rsi_healthy")
            elif e.rsi <= (100 - rsi_max):
                return None
            if t.ema_fast < t.ema_slow:
                score += 12; reasons.append("h1_bear")
            if b.ema_bias > 0 and e.ema_fast < b.ema_bias:
                score += 8; reasons.append("h4_bear")
            if e.ema_slow > 0:
                dist_atr = abs(ctx.bid - e.ema_slow) / max(ctx.atr_value, 1e-10)
                if dist_atr < 0.8:
                    score += 14; reasons.append("pullback_zone")
                elif dist_atr < 1.5:
                    score += 6; reasons.append("near_ema")
            if e.minus_di > e.plus_di:
                score += 8; reasons.append("di_bear")
            if ctx.entry_tf.momentum < -0.2:
                score += 8; reasons.append("momentum_bear")

        if side is None or score < min_score:
            return None

        entry, sl, tp, rr = self._levels(ctx, spec, side, sl_mult, min_rr * 1.5)
        if rr < min_rr:
            return None

        return Signal(ctx.symbol, Action.OPEN, side, SetupType.TREND_CONTINUATION,
                      score, sl, tp, entry, rr, reasons)

    # ═════════════════════════════════════════════════════════
    #  2. BREAKOUT EXPANSION
    # ═════════════════════════════════════════════════════════

    def _breakout_expansion(self, ctx: MarketContext, spec: SymbolSpec) -> Optional[Signal]:
        bcfg = self.cfg.breakout_cfg(spec.requested)
        if not bcfg.get("enabled", True):
            return None

        min_adx = float(bcfg.get("min_adx", 16))
        sl_mult = float(bcfg.get("sl_atr_mult", 2.0))
        max_zscore = float(bcfg.get("max_zscore", 2.0))
        min_vol_ratio = float(bcfg.get("min_volume_ratio", 1.05))
        min_score = self.cfg.min_score_breakout_expansion
        min_rr = self.cfg.min_rr_breakout

        e = ctx.entry_tf
        if e.adx < min_adx:
            return None

        score = 0.0
        reasons: List[str] = []
        side: Optional[Side] = None

        if ctx.ask > e.donchian_high > 0 and e.zscore < max_zscore:
            if e.plus_di > e.minus_di and e.macd_hist > 0:
                side = Side.BUY
                score += 30; reasons.append("don_break_up")
                if 50 < e.rsi < 78: score += 10; reasons.append("rsi_mom")
                if e.volume_sma >= min_vol_ratio:
                    score += 12; reasons.append("vol_confirm")
                if e.compression < 0.85:
                    score += 10; reasons.append("coil_break")
                if e.macd_hist > abs(e.macd_signal) * 0.5:
                    score += 8; reasons.append("macd_push")
                if ctx.trend_tf.ema_fast > ctx.trend_tf.ema_slow:
                    score += 8; reasons.append("h1_confirm")
                if e.momentum > 0.3:
                    score += 8; reasons.append("accel_up")

        elif ctx.bid < e.donchian_low > 0 and e.zscore > -max_zscore:
            if e.minus_di > e.plus_di and e.macd_hist < 0:
                side = Side.SELL
                score += 30; reasons.append("don_break_dn")
                if 22 < e.rsi < 50: score += 10; reasons.append("rsi_mom")
                if e.volume_sma >= min_vol_ratio:
                    score += 12; reasons.append("vol_confirm")
                if e.compression < 0.85:
                    score += 10; reasons.append("coil_break")
                if abs(e.macd_hist) > abs(e.macd_signal) * 0.5:
                    score += 8; reasons.append("macd_push")
                if ctx.trend_tf.ema_fast < ctx.trend_tf.ema_slow:
                    score += 8; reasons.append("h1_confirm")
                if e.momentum < -0.3:
                    score += 8; reasons.append("accel_dn")

        if side is None or score < min_score:
            return None

        entry, sl, tp, rr = self._levels(ctx, spec, side, sl_mult, min_rr * 1.8)
        if rr < min_rr:
            return None

        return Signal(ctx.symbol, Action.OPEN, side, SetupType.BREAKOUT_EXPANSION,
                      score, sl, tp, entry, rr, reasons)

    # ═════════════════════════════════════════════════════════
    #  3. PULLBACK TO TREND
    # ═════════════════════════════════════════════════════════

    def _pullback_to_trend(self, ctx: MarketContext, spec: SymbolSpec) -> Optional[Signal]:
        pcfg = self.cfg.pullback_cfg(spec.requested)
        if not pcfg.get("enabled", True):
            return None

        min_adx_h1 = float(pcfg.get("min_adx_h1", 18))
        sl_mult = float(pcfg.get("sl_atr_mult", 1.6))
        ema_prox = float(pcfg.get("ema_proximity_atr", 1.0))
        min_score = self.cfg.min_score_pullback_to_trend
        min_rr = self.cfg.min_rr_pullback

        e, t, b = ctx.entry_tf, ctx.trend_tf, ctx.bias_tf

        # H1 trend must be defined
        if t.adx < min_adx_h1:
            return None

        score = 0.0
        reasons: List[str] = []
        side: Optional[Side] = None

        h1_bull = t.ema_fast > t.ema_slow and t.plus_di > t.minus_di
        h1_bear = t.ema_fast < t.ema_slow and t.minus_di > t.plus_di
        h4_bull = b.ema_fast > b.ema_slow if b.ema_fast > 0 else False
        h4_bear = b.ema_fast < b.ema_slow if b.ema_fast > 0 else False

        if h1_bull:
            # Entry TF should be in pullback (EMA slow above bid, RSI moderate)
            rsi_max_buy = float(pcfg.get("pullback_rsi_max_buy", 58))
            rsi_min_buy = float(pcfg.get("pullback_rsi_min_buy", 35))
            price_near_ema = (e.ema_slow > 0 and
                              abs(ctx.bid - e.ema_slow) < ctx.atr_value * ema_prox)
            if not price_near_ema:
                return None
            if not (rsi_min_buy <= e.rsi <= rsi_max_buy):
                return None
            # Require bullish reversal signal on entry TF
            macd_turning = e.macd_hist > e.macd_signal * 0.8
            if not (macd_turning or (e.rsi > 40 and e.macd_hist > -0.5 * abs(e.macd_signal))):
                return None
            side = Side.BUY
            score += 25; reasons.append("h1_bull_pullback")
            if h4_bull: score += 12; reasons.append("h4_confirm")
            if price_near_ema: score += 12; reasons.append("ema_touch")
            if rsi_min_buy < e.rsi < 50: score += 10; reasons.append("rsi_recovery")
            if macd_turning: score += 10; reasons.append("macd_turn")
            if e.momentum > 0.1: score += 8; reasons.append("mom_recovering")
            if t.adx > 25: score += 8; reasons.append("h1_strong_trend")

        elif h1_bear:
            rsi_min_sell = float(pcfg.get("pullback_rsi_min_sell", 42))
            rsi_max_sell = float(pcfg.get("pullback_rsi_max_sell", 65))
            price_near_ema = (e.ema_slow > 0 and
                              abs(ctx.ask - e.ema_slow) < ctx.atr_value * ema_prox)
            if not price_near_ema:
                return None
            if not (rsi_min_sell <= e.rsi <= rsi_max_sell):
                return None
            macd_turning = e.macd_hist < e.macd_signal * 0.8
            if not (macd_turning or (e.rsi < 60 and e.macd_hist < 0.5 * abs(e.macd_signal))):
                return None
            side = Side.SELL
            score += 25; reasons.append("h1_bear_pullback")
            if h4_bear: score += 12; reasons.append("h4_confirm")
            if price_near_ema: score += 12; reasons.append("ema_touch")
            if 50 < e.rsi < rsi_max_sell: score += 10; reasons.append("rsi_recovery")
            if macd_turning: score += 10; reasons.append("macd_turn")
            if e.momentum < -0.1: score += 8; reasons.append("mom_recovering")
            if t.adx > 25: score += 8; reasons.append("h1_strong_trend")

        if side is None or score < min_score:
            return None

        entry, sl, tp, rr = self._levels(ctx, spec, side, sl_mult, min_rr * 1.5)
        if rr < min_rr:
            return None

        return Signal(ctx.symbol, Action.OPEN, side, SetupType.PULLBACK_TO_TREND,
                      score, sl, tp, entry, rr, reasons)

    # ═════════════════════════════════════════════════════════
    #  4. CRT SCALP (mean-reversion in range, XAU primary)
    # ═════════════════════════════════════════════════════════

    def _crt_scalp(self, ctx: MarketContext, spec: SymbolSpec) -> Optional[Signal]:
        scfg = self.cfg.scalp_cfg(spec.requested)
        if not scfg.get("enabled", True):
            return None

        max_adx = float(scfg.get("max_adx", 24))
        sl_mult = float(scfg.get("sl_atr_mult", 1.2))
        rsi_ob = float(scfg.get("rsi_ob", 68))
        rsi_os = float(scfg.get("rsi_os", 32))
        z_thresh = float(scfg.get("zscore_threshold", 0.9))
        min_score = self.cfg.min_score_crt_scalp
        min_rr = self.cfg.min_rr_scalp

        e = ctx.entry_tf
        if e.adx > max_adx:
            return None

        score = 0.0
        reasons: List[str] = []
        side: Optional[Side] = None

        if ctx.bid <= e.bb_lower and e.rsi < rsi_os and e.zscore < -z_thresh:
            side = Side.BUY
            score += 25; reasons.append("bb_low_bounce")
            if e.rsi < 28: score += 12; reasons.append("rsi_extreme")
            if e.zscore < -1.5: score += 10; reasons.append("z_extreme")
            if e.macd_hist > e.macd_signal * -0.3:
                score += 8; reasons.append("macd_turn")
            if e.momentum > -0.1:
                score += 6; reasons.append("mom_stabilize")

        elif ctx.ask >= e.bb_upper and e.rsi > rsi_ob and e.zscore > z_thresh:
            side = Side.SELL
            score += 25; reasons.append("bb_high_reject")
            if e.rsi > 72: score += 12; reasons.append("rsi_extreme")
            if e.zscore > 1.5: score += 10; reasons.append("z_extreme")
            if e.macd_hist < e.macd_signal * 0.3:
                score += 8; reasons.append("macd_turn")
            if e.momentum < 0.1:
                score += 6; reasons.append("mom_stabilize")

        if side is None or score < min_score:
            return None

        entry, sl, tp, rr = self._levels(ctx, spec, side, sl_mult, min_rr * 1.3)
        if rr < min_rr:
            return None

        return Signal(ctx.symbol, Action.OPEN, side, SetupType.CRT_SCALP,
                      score, sl, tp, entry, rr, reasons)

    # ═════════════════════════════════════════════════════════
    #  5. MANUAL STYLE REPLICATION
    #  Captures momentum acceleration after compression
    # ═════════════════════════════════════════════════════════

    def _manual_style(self, ctx: MarketContext, spec: SymbolSpec) -> Optional[Signal]:
        mcfg = self.cfg.manual_cfg(spec.requested)
        if not mcfg.get("enabled", True):
            return None

        min_adx = float(mcfg.get("min_adx", 14))
        sl_mult = float(mcfg.get("sl_atr_mult", 1.8))
        accel_thresh = float(mcfg.get("accel_threshold", 0.35))
        comp_bars = int(mcfg.get("compression_bars", 6))
        min_score = self.cfg.min_score_manual_style
        min_rr = self.cfg.min_rr_manual

        e, t = ctx.entry_tf, ctx.trend_tf

        if e.adx < min_adx:
            return None

        # Need meaningful momentum after compression
        if e.compression > 1.0:
            return None  # not compressed — skip manual style
        if abs(e.momentum) < accel_thresh:
            return None  # no acceleration

        score = 0.0
        reasons: List[str] = []
        side: Optional[Side] = None

        if e.momentum > accel_thresh and e.ema_fast > e.ema_slow:
            side = Side.BUY
            score += 28; reasons.append("accel_bull")
            if e.compression < 0.7:
                score += 14; reasons.append("strong_coil")
            elif e.compression < 0.85:
                score += 8; reasons.append("coil")
            if t.ema_fast > t.ema_slow:
                score += 12; reasons.append("h1_bull")
            if e.macd_hist > 0:
                score += 10; reasons.append("macd_bull")
            if e.rsi > 50 and e.rsi < 75:
                score += 8; reasons.append("rsi_ok")
            if e.volume_sma > 1.1:
                score += 6; reasons.append("vol_surge")
            if e.plus_di > e.minus_di:
                score += 6; reasons.append("di_bull")

        elif e.momentum < -accel_thresh and e.ema_fast < e.ema_slow:
            side = Side.SELL
            score += 28; reasons.append("accel_bear")
            if e.compression < 0.7:
                score += 14; reasons.append("strong_coil")
            elif e.compression < 0.85:
                score += 8; reasons.append("coil")
            if t.ema_fast < t.ema_slow:
                score += 12; reasons.append("h1_bear")
            if e.macd_hist < 0:
                score += 10; reasons.append("macd_bear")
            if e.rsi < 50 and e.rsi > 25:
                score += 8; reasons.append("rsi_ok")
            if e.volume_sma > 1.1:
                score += 6; reasons.append("vol_surge")
            if e.minus_di > e.plus_di:
                score += 6; reasons.append("di_bear")

        if side is None or score < min_score:
            return None

        entry, sl, tp, rr = self._levels(ctx, spec, side, sl_mult, min_rr * 1.5)
        if rr < min_rr:
            return None

        return Signal(ctx.symbol, Action.OPEN, side, SetupType.MANUAL_STYLE,
                      score, sl, tp, entry, rr, reasons)

    # ═════════════════════════════════════════════════════════
    #  LEVEL CALCULATION (shared)
    # ═════════════════════════════════════════════════════════

    def _levels(self, ctx: MarketContext, spec: SymbolSpec,
                side: Side, sl_atr_mult: float, target_rr: float) -> tuple:
        point = spec.point
        atr = ctx.atr_value
        min_stop = max(spec.stops_level + spec.freeze_level + 5, 10) * point
        sl_dist = max(atr * sl_atr_mult, min_stop)
        tp_dist = sl_dist * target_rr

        if side == Side.BUY:
            entry = ctx.ask
            sl = entry - sl_dist
            tp = entry + tp_dist
        else:
            entry = ctx.bid
            sl = entry + sl_dist
            tp = entry - tp_dist

        rr = tp_dist / max(sl_dist, 1e-10)
        return entry, sl, tp, rr
