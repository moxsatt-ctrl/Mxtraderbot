"""
GoldVault Pro — MT5 Adapter
Robust abstraction over MetaTrader5 Python API.
Handles safe initialization, reconnection, and all broker calls.
"""
from __future__ import annotations
import time
import logging
from typing import Any, Dict, List, Optional, Tuple

log = logging.getLogger("gvpro.mt5")

try:
    import MetaTrader5 as mt5
except ImportError:
    mt5 = None  # type: ignore


class MT5:
    """Singleton-style MT5 connection manager."""

    _initialized: bool = False
    _last_init_attempt: float = 0.0
    _symbol_cache: Dict[str, Any] = {}

    # ── Connection ───────────────────────────────────────────
    @classmethod
    def available(cls) -> bool:
        return mt5 is not None

    @classmethod
    def init(cls) -> bool:
        if mt5 is None:
            return False
        if cls._initialized:
            return True
        # Rate-limit init attempts
        if time.time() - cls._last_init_attempt < 5.0:
            return False
        cls._last_init_attempt = time.time()
        try:
            ok = mt5.initialize()
            cls._initialized = bool(ok)
            if cls._initialized:
                info = mt5.account_info()
                if info:
                    log.info(
                        f"MT5 connected: login={info.login} server={info.server} "
                        f"balance={info.balance:.2f} equity={info.equity:.2f}"
                    )
            return cls._initialized
        except Exception as e:
            log.error(f"MT5 init failed: {e}")
            return False

    @classmethod
    def ensure(cls) -> bool:
        """Make sure we're connected, attempt reconnect if needed."""
        if cls._initialized:
            # Quick health check
            try:
                info = mt5.terminal_info()
                if info is not None:
                    return True
            except Exception:
                pass
            cls._initialized = False
        return cls.init()

    @classmethod
    def shutdown(cls):
        if mt5 is not None and cls._initialized:
            mt5.shutdown()
            cls._initialized = False

    # ── Account ──────────────────────────────────────────────
    @classmethod
    def account_info(cls):
        if not cls.ensure():
            return None
        return mt5.account_info()

    @classmethod
    def equity(cls) -> float:
        info = cls.account_info()
        return float(info.equity) if info else 0.0

    @classmethod
    def balance(cls) -> float:
        info = cls.account_info()
        return float(info.balance) if info else 0.0

    @classmethod
    def free_margin(cls) -> float:
        info = cls.account_info()
        return float(info.margin_free) if info else 0.0

    @classmethod
    def margin_level(cls) -> float:
        info = cls.account_info()
        if info and info.margin > 0:
            return float(info.equity / info.margin * 100)
        return 9999.0

    # ── Symbol ───────────────────────────────────────────────
    @classmethod
    def symbol_info(cls, name: str):
        if not cls.ensure():
            return None
        # Enable the symbol first
        mt5.symbol_select(name, True)
        info = mt5.symbol_info(name)
        if info is not None:
            cls._symbol_cache[name] = info
        return info

    @classmethod
    def symbol_info_tick(cls, name: str):
        if not cls.ensure():
            return None
        return mt5.symbol_info_tick(name)

    # ── Data ─────────────────────────────────────────────────
    @classmethod
    def timeframe(cls, tf_str: str) -> Optional[int]:
        """Convert string timeframe to MT5 constant."""
        if mt5 is None:
            return None
        mapping = {
            "M1": mt5.TIMEFRAME_M1, "M5": mt5.TIMEFRAME_M5,
            "M15": mt5.TIMEFRAME_M15, "M30": mt5.TIMEFRAME_M30,
            "H1": mt5.TIMEFRAME_H1, "H4": mt5.TIMEFRAME_H4,
            "D1": mt5.TIMEFRAME_D1, "W1": mt5.TIMEFRAME_W1,
        }
        return mapping.get(tf_str.upper())

    @classmethod
    def get_rates(cls, symbol: str, tf_str: str, count: int = 300) -> Optional[List[Dict]]:
        """Get OHLCV data as list of dicts. Works with numpy structured arrays and plain tuples."""
        if not cls.ensure():
            return None
        tf = cls.timeframe(tf_str)
        if tf is None:
            return None
        rates = mt5.copy_rates_from_pos(symbol, tf, 0, count)
        if rates is None or len(rates) < 50:
            return None
        result = []
        for r in rates:
            try:
                result.append({
                    "time": float(r[0]), "open": float(r[1]),
                    "high": float(r[2]), "low": float(r[3]),
                    "close": float(r[4]), "tick_volume": float(r[5]),
                })
            except (IndexError, TypeError, KeyError):
                try:
                    result.append({
                        "time": float(r["time"]), "open": float(r["open"]),
                        "high": float(r["high"]), "low": float(r["low"]),
                        "close": float(r["close"]), "tick_volume": float(r["tick_volume"]),
                    })
                except Exception:
                    continue
        return result if len(result) >= 50 else None

    # ── Positions ────────────────────────────────────────────
    @classmethod
    def positions_get(cls, symbol: str = None) -> List:
        if not cls.ensure():
            return []
        if symbol:
            return list(mt5.positions_get(symbol=symbol) or [])
        return list(mt5.positions_get() or [])

    @classmethod
    def positions_total(cls) -> int:
        if not cls.ensure():
            return 0
        return mt5.positions_total()

    # ── Orders ───────────────────────────────────────────────
    @classmethod
    def order_send(cls, request: Dict[str, Any]):
        if not cls.ensure():
            return None
        return mt5.order_send(request)

    @classmethod
    def order_check(cls, request: Dict[str, Any]):
        if not cls.ensure():
            return None
        return mt5.order_check(request)

    @classmethod
    def order_calc_profit(cls, action: int, symbol: str, volume: float,
                          price_open: float, price_close: float) -> Optional[float]:
        if not cls.ensure():
            return None
        try:
            result = mt5.order_calc_profit(action, symbol, volume, price_open, price_close)
            return float(result) if result is not None else None
        except Exception:
            return None

    # ── Constants ────────────────────────────────────────────
    @classmethod
    def ORDER_BUY(cls) -> int: return mt5.ORDER_TYPE_BUY if mt5 else 0
    @classmethod
    def ORDER_SELL(cls) -> int: return mt5.ORDER_TYPE_SELL if mt5 else 1
    @classmethod
    def ACTION_DEAL(cls) -> int: return mt5.TRADE_ACTION_DEAL if mt5 else 1
    @classmethod
    def ACTION_SLTP(cls) -> int: return mt5.TRADE_ACTION_SLTP if mt5 else 6
    @classmethod
    def TIME_GTC(cls) -> int: return mt5.ORDER_TIME_GTC if mt5 else 0
    @classmethod
    def FILL_FOK(cls) -> Optional[int]: return mt5.ORDER_FILLING_FOK if mt5 else None
    @classmethod
    def FILL_IOC(cls) -> Optional[int]: return mt5.ORDER_FILLING_IOC if mt5 else None
    @classmethod
    def FILL_RETURN(cls) -> Optional[int]: return mt5.ORDER_FILLING_RETURN if mt5 else None
    @classmethod
    def RET_DONE(cls) -> int: return mt5.TRADE_RETCODE_DONE if mt5 else 10009
    @classmethod
    def RET_PLACED(cls) -> int: return mt5.TRADE_RETCODE_PLACED if mt5 else 10008
    @classmethod
    def EXEMODE_MARKET(cls) -> int: return mt5.SYMBOL_TRADE_EXECUTION_MARKET if mt5 else 0
