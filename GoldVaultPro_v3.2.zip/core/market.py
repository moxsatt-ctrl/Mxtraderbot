"""
GoldVault Pro v3.0 — Market Analyzer
Multi-timeframe analysis with momentum, compression, and enhanced regime detection.
"""
from __future__ import annotations
import logging
import time
from typing import Dict, List, Optional

from .config import Config
from .mt5 import MT5
from .types import IndicatorSet, MarketContext, Regime, SymbolSpec
from . import indicators as ind

log = logging.getLogger("gvpro.market")


class MarketAnalyzer:
    def __init__(self, cfg: Config):
        self.cfg = cfg

    def analyze(self, spec: SymbolSpec) -> Optional[MarketContext]:
        tick = MT5.symbol_info_tick(spec.actual)
        if tick is None:
            return None

        tfs = self.cfg.timeframes(spec.requested)
        entry_data = self._load(spec.actual, tfs.get("entry", "M15"))
        trend_data = self._load(spec.actual, tfs.get("trend", "H1"))
        bias_data = self._load(spec.actual, tfs.get("bias", "H4"))

        if entry_data is None:
            return None

        entry_ind = self._compute(entry_data, spec.requested)
        trend_ind = self._compute(trend_data, spec.requested) if trend_data else IndicatorSet()
        bias_ind = self._compute(bias_data, spec.requested) if bias_data else IndicatorSet()

        bid, ask = float(tick.bid), float(tick.ask)
        atr_val = entry_ind.atr
        spread_price = ask - bid
        spread_pct = (spread_price / max(atr_val, 1e-10)) * 100.0

        return MarketContext(
            symbol=spec.actual, bid=bid, ask=ask,
            spread_points=spread_price / max(spec.point, 1e-10),
            spread_pct_of_atr=spread_pct,
            regime=self._detect_regime(entry_ind, trend_ind, bias_ind),
            entry_tf=entry_ind, trend_tf=trend_ind, bias_tf=bias_ind,
            atr_value=atr_val,
            atr_points=atr_val / max(spec.point, 1e-10),
            timestamp=time.time(),
            recent_closes=entry_data["close"][-20:],
        )

    _TF_SECONDS = {"M1": 60, "M5": 300, "M15": 900, "M30": 1800, "H1": 3600, "H4": 14400, "D1": 86400}

    def _load(self, symbol: str, tf_str: str) -> Optional[Dict[str, List[float]]]:
        rates = MT5.get_rates(symbol, tf_str, 300)
        if rates is None or len(rates) < 50:
            return None
        last = rates[-1]
        if "time" in last:
            bar_age = time.time() - float(last["time"])
            tf_sec = self._TF_SECONDS.get(tf_str, 900)
            if bar_age > tf_sec * 3:
                log.warning("[DATA] %s %s last bar is %.0fs old (>%ds) — indicators may be stale",
                            symbol, tf_str, bar_age, tf_sec * 3)
        return {
            "open":   [float(r["open"])        for r in rates],
            "high":   [float(r["high"])        for r in rates],
            "low":    [float(r["low"])         for r in rates],
            "close":  [float(r["close"])       for r in rates],
            "volume": [float(r["tick_volume"]) for r in rates],
        }

    def _compute(self, data: Dict[str, List[float]], symbol: str) -> IndicatorSet:
        closes  = data["close"]
        highs   = data["high"]
        lows    = data["low"]
        volumes = data["volume"]

        tcfg = self.cfg.trend_cfg(symbol)
        scfg = self.cfg.scalp_cfg(symbol)

        adx_val, pdi, ndi = ind.adx(highs, lows, closes)
        macd_l, macd_s, macd_h = ind.macd(
            closes,
            int(tcfg.get("macd_fast", 12)),
            int(tcfg.get("macd_slow", 26)),
            int(tcfg.get("macd_signal", 9)),
        )
        bb_u, bb_m, bb_l = ind.bollinger(
            closes,
            int(scfg.get("bb_period", 20)),
            float(scfg.get("bb_std", 2.0)),
        )
        don_h, don_l = ind.donchian(
            highs, lows,
            int(self.cfg.breakout_cfg(symbol).get("donchian_period", 55)),
        )
        atr_val = ind.atr(highs, lows, closes, int(tcfg.get("atr_period", 14)))
        mom = ind.momentum(closes, atr_val, lookback=3)
        comp = ind.compression_ratio(highs, lows, closes, short_period=5, long_period=20)

        return IndicatorSet(
            ema_fast=ind.ema(closes, int(tcfg.get("ema_fast", 9))),
            ema_slow=ind.ema(closes, int(tcfg.get("ema_slow", 21))),
            ema_trend=ind.ema(closes, int(tcfg.get("ema_trend", 50))),
            ema_bias=ind.ema(closes, int(tcfg.get("ema_bias", 200))),
            rsi=ind.rsi(closes, int(tcfg.get("rsi_period", 14))),
            adx=adx_val, plus_di=pdi, minus_di=ndi,
            macd_line=macd_l, macd_signal=macd_s, macd_hist=macd_h,
            atr=atr_val,
            bb_upper=bb_u, bb_middle=bb_m, bb_lower=bb_l,
            donchian_high=don_h, donchian_low=don_l,
            zscore=ind.zscore(closes),
            volume_sma=ind.volume_ratio(volumes),
            momentum=mom,
            compression=comp,
        )

    def _detect_regime(self, entry: IndicatorSet, trend: IndicatorSet,
                       bias: IndicatorSet) -> Regime:
        adx_e = entry.adx
        adx_t = trend.adx if trend.adx > 0 else adx_e
        ema_bull = entry.ema_fast > entry.ema_slow > entry.ema_trend
        ema_bear = entry.ema_fast < entry.ema_slow < entry.ema_trend

        # Breakout detection: donchian break + compression unwinding
        if entry.compression < 0.75 and adx_e >= 15:
            if ema_bull and entry.plus_di > entry.minus_di:
                return Regime.BREAKOUT
            if ema_bear and entry.minus_di > entry.plus_di:
                return Regime.BREAKOUT

        # Trend with decent ADX and EMA alignment
        if adx_e >= 20 and adx_t >= 16:
            if ema_bull and entry.plus_di > entry.minus_di:
                return Regime.TREND_UP
            if ema_bear and entry.minus_di > entry.plus_di:
                return Regime.TREND_DOWN

        # Weaker trend — EMA alignment enough
        if adx_e >= 16:
            if ema_bull: return Regime.TREND_UP
            if ema_bear: return Regime.TREND_DOWN

        # Volatile range (high z-score but low ADX)
        if abs(entry.zscore) > 2.0 and adx_e < 20:
            return Regime.VOLATILE

        return Regime.RANGE
