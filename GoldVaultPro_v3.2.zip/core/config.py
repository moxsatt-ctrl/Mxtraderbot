"""
GoldVault Pro v3.0 — Configuration Loader
Profile-aware: risk/exit/pyramid params from active profile.
Per-symbol per-strategy configuration from symbol sections.
"""
from __future__ import annotations
import os
import yaml
from pathlib import Path
from typing import Any, Dict, List


class Config:
    def __init__(self, path: str = None):
        if path is None:
            path = os.environ.get(
                "GVPRO_CONFIG",
                str(Path(__file__).parent.parent / "config" / "settings.yaml"),
            )
        with open(path, "r", encoding="utf-8") as f:
            self._raw: Dict[str, Any] = yaml.safe_load(f)
        self._profile_name = str(self._raw.get("active_profile", "BALANCED")).upper()
        self._profile: Dict[str, Any] = self._raw.get("profiles", {}).get(self._profile_name, {})

    def _g(self, *keys, default=None):
        node = self._raw
        for k in keys:
            if isinstance(node, dict):
                node = node.get(k, default)
            else:
                return default
        return node if node is not None else default

    def _p(self, key: str, default=None):
        return self._profile.get(key, default)

    # ── General ──────────────────────────────────────────────
    @property
    def magic(self) -> int: return int(self._g("general", "magic", default=20260401))
    @property
    def comment(self) -> str: return str(self._g("general", "comment", default="GVPro"))
    @property
    def loop_sec(self) -> float: return float(self._g("general", "loop_interval_sec", default=1.2))
    @property
    def log_level(self) -> str: return str(self._g("general", "log_level", default="INFO"))
    @property
    def profile_name(self) -> str: return self._profile_name

    # ── Symbols ──────────────────────────────────────────────
    @property
    def symbols(self) -> List[str]: return list(self._g("symbols", default=["XAUUSD", "BTCUSD"]))

    # ═════════════════════════════════════════════════════════
    #  PROFILE-DRIVEN VALUES
    # ═════════════════════════════════════════════════════════

    @property
    def risk_pct(self) -> float: return float(self._p("risk_per_trade_pct", 0.8))
    @property
    def max_daily_dd_pct(self) -> float: return float(self._p("max_daily_drawdown_pct", 3.5))
    @property
    def max_total_dd_pct(self) -> float: return float(self._p("max_total_drawdown_pct", 9.0))
    @property
    def max_basket_risk_pct(self) -> float: return float(self._p("max_basket_risk_pct", 2.5))
    @property
    def max_pos_per_symbol(self) -> int: return int(self._p("max_positions_per_symbol", 3))
    @property
    def max_total_pos(self) -> int: return int(self._p("max_total_positions", 5))

    # ── Pyramid ──────────────────────────────────────────────
    @property
    def pyramid_enabled(self) -> bool: return bool(self._p("pyramid_enabled", True))
    @property
    def pyramid_max_adds(self) -> int: return int(self._p("pyramid_max_adds", 2))
    @property
    def pyramid_require_be(self) -> bool: return bool(self._p("pyramid_require_be", True))
    @property
    def pyramid_min_advance_atr(self) -> float: return float(self._p("pyramid_min_advance_atr", 1.1))
    @property
    def pyramid_size_pct(self) -> float: return float(self._p("pyramid_size_pct", 55))

    # ── Partials ─────────────────────────────────────────────
    @property
    def partial1_pct(self) -> float: return float(self._p("partial1_pct", 40))
    @property
    def partial1_rr(self) -> float: return float(self._p("partial1_rr", 0.9))
    @property
    def partial2_pct(self) -> float: return float(self._p("partial2_pct", 30))
    @property
    def partial2_rr(self) -> float: return float(self._p("partial2_rr", 2.0))
    @property
    def partial3_pct(self) -> float: return float(self._p("partial3_pct", 20))
    @property
    def partial3_rr(self) -> float: return float(self._p("partial3_rr", 3.5))

    # ── Trailing / Giveback ──────────────────────────────────
    @property
    def trail_start_rr(self) -> float: return float(self._p("trail_start_rr", 1.7))
    @property
    def trail_atr_mult(self) -> float: return float(self._p("trail_atr_mult", 0.9))
    @property
    def giveback_pct(self) -> float: return float(self._p("giveback_pct", 22))
    @property
    def giveback_usd(self) -> float: return float(self._p("giveback_usd", 4.0))

    # ── Per-strategy score thresholds ────────────────────────
    @property
    def min_score_trend_continuation(self) -> float:
        return float(self._p("min_score_trend_continuation", 30))
    @property
    def min_score_breakout_expansion(self) -> float:
        return float(self._p("min_score_breakout_expansion", 26))
    @property
    def min_score_pullback_to_trend(self) -> float:
        return float(self._p("min_score_pullback_to_trend", 33))
    @property
    def min_score_crt_scalp(self) -> float:
        return float(self._p("min_score_crt_scalp", 26))
    @property
    def min_score_manual_style(self) -> float:
        return float(self._p("min_score_manual_style", 28))

    # ── Per-strategy RR thresholds ───────────────────────────
    @property
    def min_rr_trend(self) -> float: return float(self._p("min_rr_trend", 1.7))
    @property
    def min_rr_breakout(self) -> float: return float(self._p("min_rr_breakout", 1.7))
    @property
    def min_rr_pullback(self) -> float: return float(self._p("min_rr_pullback", 1.5))
    @property
    def min_rr_scalp(self) -> float: return float(self._p("min_rr_scalp", 1.2))
    @property
    def min_rr_manual(self) -> float: return float(self._p("min_rr_manual", 1.5))

    # ═════════════════════════════════════════════════════════
    #  RISK ABSOLUTES
    # ═════════════════════════════════════════════════════════

    def _ra(self, key: str, default):
        return self._g("risk_absolutes", key, default=default)

    @property
    def xau_max_vol(self) -> float: return float(self._ra("xau_max_volume", 0.10))
    @property
    def btc_max_vol(self) -> float: return float(self._ra("btc_max_volume", 0.05))
    @property
    def xau_min_vol(self) -> float: return float(self._ra("xau_min_volume", 0.01))
    @property
    def btc_min_vol(self) -> float: return float(self._ra("btc_min_volume", 0.01))
    @property
    def max_risk_discrepancy(self) -> float: return float(self._ra("max_risk_discrepancy_ratio", 2.5))
    @property
    def xau_max_risk_usd(self) -> float: return float(self._ra("xau_max_risk_usd", 15.0))
    @property
    def btc_max_risk_usd(self) -> float: return float(self._ra("btc_max_risk_usd", 20.0))
    @property
    def min_free_margin_pct(self) -> float: return float(self._ra("min_free_margin_pct", 40.0))
    @property
    def hard_stop_multiplier(self) -> float: return float(self._ra("hard_stop_multiplier", 1.5))

    def abs_max_vol(self, symbol: str) -> float:
        return self.xau_max_vol if self._is_xau(symbol) else self.btc_max_vol

    def abs_max_risk(self, symbol: str) -> float:
        return self.xau_max_risk_usd if self._is_xau(symbol) else self.btc_max_risk_usd

    # ═════════════════════════════════════════════════════════
    #  SYMBOL SECTIONS
    # ═════════════════════════════════════════════════════════

    def _sym_key(self, symbol: str) -> str:
        return "xauusd" if self._is_xau(symbol) else "btcusd"

    def symbol_cfg(self, symbol: str) -> Dict[str, Any]:
        return dict(self._g(self._sym_key(symbol), default={}))

    def timeframes(self, symbol: str) -> Dict[str, str]:
        return self.symbol_cfg(symbol).get("timeframes", {"entry": "M15", "trend": "H1", "bias": "H4"})

    # ── Per-symbol per-strategy config ───────────────────────

    def strategy_cfg(self, symbol: str, strategy_name: str) -> Dict[str, Any]:
        """Get strategy-specific config for a symbol."""
        return self.symbol_cfg(symbol).get("strategies", {}).get(strategy_name, {})

    def trend_cfg(self, symbol: str) -> Dict[str, Any]:
        return self.strategy_cfg(symbol, "trend_continuation")

    def breakout_cfg(self, symbol: str) -> Dict[str, Any]:
        return self.strategy_cfg(symbol, "breakout_expansion")

    def pullback_cfg(self, symbol: str) -> Dict[str, Any]:
        return self.strategy_cfg(symbol, "pullback_to_trend")

    def scalp_cfg(self, symbol: str) -> Dict[str, Any]:
        return self.strategy_cfg(symbol, "crt_scalp")

    def manual_cfg(self, symbol: str) -> Dict[str, Any]:
        return self.strategy_cfg(symbol, "manual_style")

    # ── Exit config ──────────────────────────────────────────

    def exit_cfg(self, symbol: str) -> Dict[str, Any]:
        return self.symbol_cfg(symbol).get("exit", {})

    def be_usd(self, symbol: str) -> float:
        return float(self.exit_cfg(symbol).get("be_usd", 0.0))

    def partial1_usd(self, symbol: str) -> float:
        return float(self.exit_cfg(symbol).get("partial1_usd", 0.0))

    def partial2_usd(self, symbol: str) -> float:
        return float(self.exit_cfg(symbol).get("partial2_usd", 0.0))

    def lock_after_partial2(self, symbol: str) -> bool:
        return bool(self.exit_cfg(symbol).get("lock_after_partial2", True))

    def lock_atr_mult(self, symbol: str) -> float:
        return float(self.exit_cfg(symbol).get("lock_atr_mult", 0.5))

    def time_stop_scalp_min(self, symbol: str) -> float:
        return float(self.exit_cfg(symbol).get("time_stop_scalp_min", 20.0))

    def weakness_enabled(self, symbol: str) -> bool:
        return bool(self.exit_cfg(symbol).get("weakness_enabled", True))

    def weakness_lookback(self, symbol: str) -> int:
        return int(self.exit_cfg(symbol).get("weakness_lookback", 3))

    def weakness_rejection_pct(self, symbol: str) -> float:
        return float(self.exit_cfg(symbol).get("weakness_rejection_pct", 55))

    def giveback_tier1_pnl(self, symbol: str) -> float:
        return float(self.exit_cfg(symbol).get("giveback_tier1_pnl", 18.0))

    def giveback_tier1_pct(self, symbol: str) -> float:
        return float(self.exit_cfg(symbol).get("giveback_tier1_pct", 17))

    def giveback_tier2_pnl(self, symbol: str) -> float:
        return float(self.exit_cfg(symbol).get("giveback_tier2_pnl", 45.0))

    def giveback_tier2_pct(self, symbol: str) -> float:
        return float(self.exit_cfg(symbol).get("giveback_tier2_pct", 13))

    def spread_to_tp_ratio(self, symbol: str) -> float:
        return float(self.exit_cfg(symbol).get("spread_to_tp_ratio", 0.15))

    def max_spread_pct(self, symbol: str) -> float:
        return float(self.symbol_cfg(symbol).get("max_spread_pct_of_atr", 14))

    # ── Reentry config ───────────────────────────────────────

    def reentry_cfg(self, symbol: str) -> Dict[str, Any]:
        return self.symbol_cfg(symbol).get("reentry", {})

    def reentry_enabled(self, symbol: str) -> bool:
        return bool(self.reentry_cfg(symbol).get("enabled", True))

    def reentry_min_dist_atr(self, symbol: str) -> float:
        return float(self.reentry_cfg(symbol).get("min_dist_atr_mult", 0.8))

    def reentry_cooldown(self, symbol: str) -> float:
        return float(self.reentry_cfg(symbol).get("cooldown_sec", 20))

    def allow_add_if_campaign_profit(self, symbol: str) -> bool:
        return bool(self.reentry_cfg(symbol).get("allow_add_if_campaign_profit", True))

    # ── Campaign config ──────────────────────────────────────

    def campaign_cfg(self, symbol: str) -> Dict[str, Any]:
        return self.symbol_cfg(symbol).get("campaign", {})

    def campaign_max_entries(self, symbol: str) -> int:
        return int(self.campaign_cfg(symbol).get("max_entries", 4))

    def campaign_basket_giveback_pct(self, symbol: str) -> float:
        return float(self.campaign_cfg(symbol).get("basket_giveback_pct", 20))

    def campaign_basket_max_loss_usd(self, symbol: str) -> float:
        return float(self.campaign_cfg(symbol).get("basket_max_loss_usd", 35.0))

    # ── Sessions ─────────────────────────────────────────────
    @property
    def sessions_enabled(self) -> bool: return bool(self._g("sessions", "enabled", default=True))
    @property
    def london_start(self) -> int: return int(self._g("sessions", "london_start", default=7))
    @property
    def london_end(self) -> int: return int(self._g("sessions", "london_end", default=17))
    @property
    def ny_start(self) -> int: return int(self._g("sessions", "newyork_start", default=12))
    @property
    def ny_end(self) -> int: return int(self._g("sessions", "newyork_end", default=22))
    @property
    def asian_start(self) -> int: return int(self._g("sessions", "asian_start", default=22))
    @property
    def asian_end(self) -> int: return int(self._g("sessions", "asian_end", default=7))
    @property
    def prefer_overlap(self) -> bool: return bool(self._g("sessions", "prefer_overlap", default=True))
    @property
    def btc_ignore_session(self) -> bool: return bool(self._g("sessions", "btc_ignore_session", default=True))

    # ── Cooldowns ────────────────────────────────────────────
    @property
    def cd_after_loss(self) -> float: return float(self._g("cooldowns", "after_loss_sec", default=90))
    @property
    def cd_after_win(self) -> float: return float(self._g("cooldowns", "after_win_sec", default=10))
    @property
    def cd_after_open(self) -> float: return float(self._g("cooldowns", "after_open_sec", default=15))
    @property
    def cd_same_symbol(self) -> float: return float(self._g("cooldowns", "between_same_symbol_sec", default=20))

    # ── Execution ────────────────────────────────────────────
    @property
    def max_slippage(self) -> int: return int(self._g("execution", "max_slippage_points", default=25))
    @property
    def filling_pref(self) -> List[str]:
        return list(self._g("execution", "filling_preference", default=["RETURN", "IOC", "FOK"]))

    # ── Telegram ─────────────────────────────────────────────
    @property
    def tg_enabled(self) -> bool: return bool(self._g("telegram", "enabled", default=False))
    @property
    def tg_token(self) -> str: return str(self._g("telegram", "bot_token", default=""))
    @property
    def tg_chat(self) -> str: return str(self._g("telegram", "chat_id", default=""))

    @staticmethod
    def _is_xau(symbol: str) -> bool:
        s = symbol.upper()
        return "XAU" in s or "GOLD" in s

    @staticmethod
    def _is_btc(symbol: str) -> bool:
        s = symbol.upper()
        return "BTC" in s or "BITCOIN" in s
