"""
GoldVault Pro — Execution Engine
Handles order sending with automatic filling mode detection,
retry logic, and universal broker compatibility.

Fixes vs v2.0:
- Retry loop actually retries (was broken with `if False`)
- After opening without SL/TP, applies them via SLTP action
- Finds actual position ticket after open (not just order ID)
"""
from __future__ import annotations
import logging
import time
from typing import List, Optional

from .config import Config
from .mt5 import MT5
from .types import ExecResult, Side, SymbolSpec

log = logging.getLogger("gvpro.exec")


class Executor:
    """Sends and manages orders with full broker compatibility."""

    def __init__(self, cfg: Config):
        self.cfg = cfg
        self._fill_cache: dict[str, int] = {}

    def send_market(self, spec: SymbolSpec, side: Side, volume: float,
                    sl: float, tp: float) -> ExecResult:
        """
        Send a market order with intelligent filling mode detection.
        Tries multiple combinations to handle any broker.
        After success, ensures SL/TP is applied on the actual position.
        """
        order_type = MT5.ORDER_BUY() if side == Side.BUY else MT5.ORDER_SELL()
        is_market_exec = spec.trade_exemode == MT5.EXEMODE_MARKET()

        candidates = self._fills_for(spec.actual, is_market_exec, spec.filling_modes)
        best = ExecResult(ok=False, comment="no_attempt")

        for attempt in range(3):
            tick = MT5.symbol_info_tick(spec.actual)
            if tick is None:
                return ExecResult(ok=False, comment="tick_unavailable")
            price = tick.ask if side == Side.BUY else tick.bid

            tried_price_refresh = False
            for with_sltp in (True, False):
                for fill in candidates:
                    req = self._build_request(
                        spec, order_type, volume, price, sl, tp,
                        fill, is_market_exec, with_sltp,
                    )
                    result = self._send(req)

                    if result.ok:
                        if fill is not None:
                            self._fill_cache[spec.actual] = fill

                        # Find actual position ticket
                        pos_ticket = self._find_position(spec.actual, side)
                        if pos_ticket:
                            result.order = pos_ticket
                        else:
                            pos_ticket = int(result.order or result.deal or 0)

                        log.info(
                            f"[EXEC] OK {spec.actual} {side.value} "
                            f"vol={volume:.4f} price={price:.5f} "
                            f"sl={sl:.5f} tp={tp:.5f} ticket={pos_ticket} "
                            f"sltp_in_order={with_sltp} ret={result.retcode}"
                        )

                        # If opened without SL/TP, apply them now
                        if not with_sltp and pos_ticket > 0 and (sl > 0 or tp > 0):
                            self._apply_sltp(spec, pos_ticket, sl, tp)

                        return result

                    best = result

                    if result.retcode == 10030:
                        continue
                    if result.retcode in (10004, 10006, 10015, 10021):
                        if not tried_price_refresh:
                            tried_price_refresh = True
                            time.sleep(0.3)
                        break

            if best.ok:
                break
            time.sleep(0.5 * (attempt + 1))

        log.warning(
            f"[EXEC] FAIL {spec.actual} {side.value} vol={volume:.4f} "
            f"ret={best.retcode} cmt={best.comment}"
        )
        return best

    def modify_sl_tp(self, spec: SymbolSpec, ticket: int,
                     sl: float, tp: float) -> ExecResult:
        """Modify SL/TP of an existing position."""
        req = {
            "action": MT5.ACTION_SLTP(),
            "symbol": spec.actual,
            "position": ticket,
            "sl": sl,
            "tp": tp,
            "magic": self.cfg.magic,
            "comment": f"{self.cfg.comment}_MOD",
        }
        result = self._send(req)
        if result.ok:
            log.debug(f"[EXEC] SL/TP modified ticket={ticket} sl={sl:.5f} tp={tp:.5f}")
        return result

    def close_position(self, pos, reason: str = "PM") -> ExecResult:
        """Close a position with retry on different fill modes."""
        info = MT5.symbol_info(pos.symbol)
        tick = MT5.symbol_info_tick(pos.symbol)
        if info is None or tick is None:
            return ExecResult(ok=False, comment="info_unavailable")

        side_close = "SELL" if int(pos.type) == 0 else "BUY"
        price = tick.bid if side_close == "SELL" else tick.ask
        order_type = MT5.ORDER_SELL() if side_close == "SELL" else MT5.ORDER_BUY()

        d = info._asdict() if hasattr(info, "_asdict") else {}
        exemode = int(d.get("trade_exemode", 0) or 0)
        is_market = exemode == MT5.EXEMODE_MARKET()

        unique = self._fills_for(pos.symbol, is_market)

        best = ExecResult(ok=False, comment="no_close_attempt")
        for fill in unique:
            req = {
                "action": MT5.ACTION_DEAL(),
                "symbol": pos.symbol,
                "position": pos.ticket,
                "volume": pos.volume,
                "type": order_type,
                "price": price,
                "deviation": self.cfg.max_slippage,
                "magic": self.cfg.magic,
                "comment": f"{self.cfg.comment}_{reason}",
                "type_time": MT5.TIME_GTC(),
            }
            if fill is not None:
                req["type_filling"] = fill
            best = self._send(req)
            if best.ok:
                log.info(f"[EXEC] CLOSE ticket={pos.ticket} reason={reason} pnl={pos.profit:.2f}")
                return best

        log.warning(f"[EXEC] CLOSE_FAIL ticket={pos.ticket} reason={reason} ret={best.retcode}")
        return best

    def partial_close(self, pos, volume: float, reason: str = "PARTIAL") -> ExecResult:
        """Close a partial volume of a position."""
        info = MT5.symbol_info(pos.symbol)
        tick = MT5.symbol_info_tick(pos.symbol)
        if info is None or tick is None:
            return ExecResult(ok=False, comment="info_unavailable")

        d = info._asdict() if hasattr(info, "_asdict") else {}
        vol_step = float(d.get("volume_step", 0.01) or 0.01)
        vol_min = float(d.get("volume_min", 0.01) or 0.01)

        close_vol = max(vol_min, round(int(volume / vol_step) * vol_step, 8))
        remaining = pos.volume - close_vol
        if remaining < vol_min:
            close_vol = pos.volume

        side_close = "SELL" if int(pos.type) == 0 else "BUY"
        price = tick.bid if side_close == "SELL" else tick.ask
        order_type = MT5.ORDER_SELL() if side_close == "SELL" else MT5.ORDER_BUY()

        exemode = int(d.get("trade_exemode", 0) or 0)
        is_market = exemode == MT5.EXEMODE_MARKET()
        candidates = self._fills_for(pos.symbol, is_market)

        best = ExecResult(ok=False, comment="no_partial_attempt")
        for fill in candidates:
            req = {
                "action": MT5.ACTION_DEAL(),
                "symbol": pos.symbol,
                "position": pos.ticket,
                "volume": close_vol,
                "type": order_type,
                "price": price,
                "deviation": self.cfg.max_slippage,
                "magic": self.cfg.magic,
                "comment": f"{self.cfg.comment}_{reason}",
                "type_time": MT5.TIME_GTC(),
            }
            if fill is not None:
                req["type_filling"] = fill
            best = self._send(req)
            if best.ok:
                log.info(f"[EXEC] PARTIAL ticket={pos.ticket} vol={close_vol:.4f} reason={reason}")
                return best

        return best

    # ── Internal ─────────────────────────────────────────────

    def _apply_sltp(self, spec: SymbolSpec, ticket: int, sl: float, tp: float) -> None:
        """Apply SL/TP to an existing position (called after naked open)."""
        result = self.modify_sl_tp(spec, ticket, sl, tp)
        if result.ok:
            log.info(f"[EXEC] SL/TP applied post-open ticket={ticket} sl={sl:.5f} tp={tp:.5f}")
        else:
            log.warning(
                f"[EXEC] SL/TP post-open FAILED ticket={ticket} "
                f"ret={result.retcode} cmt={result.comment}"
            )

    def _find_position(self, symbol: str, side: Side) -> Optional[int]:
        """Find the most recently opened position for this symbol+side+magic.
        Uses time_msc (millisecond precision) when available to avoid
        same-second collisions on pyramid entries."""
        pos_type = 0 if side == Side.BUY else 1
        positions = MT5.positions_get(symbol=symbol)
        if not positions:
            return None
        matches = [
            p for p in positions
            if int(getattr(p, "magic", 0)) == self.cfg.magic
            and int(p.type) == pos_type
        ]
        if not matches:
            return None
        newest = max(matches, key=lambda p: (
            float(getattr(p, "time_msc", 0) or 0)
            or float(getattr(p, "time", 0)) * 1000
        ))
        return int(newest.ticket)

    def _send(self, request: dict) -> ExecResult:
        res = MT5.order_send(request)
        if res is None:
            return ExecResult(ok=False, comment="order_send_none")
        ret = getattr(res, "retcode", None)
        ok = ret in {MT5.RET_DONE(), MT5.RET_PLACED()}
        return ExecResult(
            ok=bool(ok), retcode=ret,
            comment=getattr(res, "comment", "") or "",
            order=getattr(res, "order", None),
            deal=getattr(res, "deal", None),
            volume=float(getattr(res, "volume", 0) or 0),
            price=float(getattr(res, "price", 0) or 0),
        )

    def _fills_for(self, symbol: str, is_market: bool,
                   extra: List[int] = None) -> List[Optional[int]]:
        """Build ordered, deduplicated fill mode list. extra = spec.filling_modes for opens."""
        seen: set = set()
        out: List[Optional[int]] = []
        def _add(f):
            if f not in seen:
                seen.add(f); out.append(f)
        cached = self._fill_cache.get(symbol)
        if cached is not None:
            _add(cached)
        for f in (extra or []):
            _add(f)
        for f in self._generic_fills(is_market):
            _add(f)
        _add(None)
        return out

    @staticmethod
    def _generic_fills(is_market: bool) -> List[int]:
        fills = []
        if is_market:
            if MT5.FILL_IOC() is not None:
                fills.append(MT5.FILL_IOC())
            if MT5.FILL_FOK() is not None:
                fills.append(MT5.FILL_FOK())
        else:
            if MT5.FILL_RETURN() is not None:
                fills.append(MT5.FILL_RETURN())
            if MT5.FILL_IOC() is not None:
                fills.append(MT5.FILL_IOC())
            if MT5.FILL_FOK() is not None:
                fills.append(MT5.FILL_FOK())
        return fills

    def _build_request(self, spec: SymbolSpec, order_type: int, volume: float,
                       price: float, sl: float, tp: float,
                       fill: Optional[int], is_market: bool,
                       with_sltp: bool) -> dict:
        req = {
            "action": MT5.ACTION_DEAL(),
            "symbol": spec.actual,
            "volume": volume,
            "type": order_type,
            "deviation": self.cfg.max_slippage,
            "magic": self.cfg.magic,
            "comment": self.cfg.comment,
            "type_time": MT5.TIME_GTC(),
        }
        if not is_market or price:
            req["price"] = price
        if fill is not None:
            req["type_filling"] = fill
        if with_sltp:
            if sl > 0:
                req["sl"] = sl
            if tp > 0:
                req["tp"] = tp
        return req
