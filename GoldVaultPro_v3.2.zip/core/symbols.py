"""
GoldVault Pro — Symbol Resolver
Detects broker-specific symbol naming and fills specifications.
Universal broker compatibility.
"""
from __future__ import annotations
import logging
from typing import List, Optional

from .mt5 import MT5
from .types import SymbolSpec

log = logging.getLogger("gvpro.symbols")

# Common symbol name variants brokers use
VARIANTS = {
    "XAUUSD": ["XAUUSD", "XAUUSD.", "XAUUSD.a", "XAUUSD.i", "XAUUSD.raw",
                "XAUUSDm", "GOLD", "GOLDm", "GOLD.", "XAU/USD"],
    "BTCUSD": ["BTCUSD", "BTCUSD.", "BTCUSD.a", "BTCUSD.i", "BTCUSDm",
                "BTC/USD", "BITCOIN", "BTCUSD.raw"],
}


def _resolve_name(requested: str) -> Optional[str]:
    """Try symbol variants until one works."""
    # Try exact name first
    info = MT5.symbol_info(requested)
    if info is not None:
        return info.name

    # Try known variants
    variants = VARIANTS.get(requested.upper(), [requested])
    for variant in variants:
        info = MT5.symbol_info(variant)
        if info is not None:
            log.info(f"Symbol {requested} resolved to {info.name}")
            return info.name

    return None


def _detect_fills(info) -> List[int]:
    """Detect allowed filling modes from symbol info."""
    d = info._asdict() if hasattr(info, "_asdict") else {}
    exemode = int(d.get("trade_exemode", 0) or 0)
    bits = int(d.get("filling_mode", 0) or 0)

    fills: List[int] = []
    fok = bool(bits & 1)
    ioc = bool(bits & 2)
    is_market = exemode == MT5.EXEMODE_MARKET()

    if is_market:
        # Market execution: RETURN is typically prohibited
        if ioc and MT5.FILL_IOC() is not None:
            fills.append(MT5.FILL_IOC())
        if fok and MT5.FILL_FOK() is not None:
            fills.append(MT5.FILL_FOK())
        if not fills:
            # Fallback: try IOC then FOK
            if MT5.FILL_IOC() is not None:
                fills.append(MT5.FILL_IOC())
            if MT5.FILL_FOK() is not None:
                fills.append(MT5.FILL_FOK())
    else:
        # Exchange/Instant execution: RETURN is usually default
        if MT5.FILL_RETURN() is not None:
            fills.append(MT5.FILL_RETURN())
        if ioc and MT5.FILL_IOC() is not None:
            fills.append(MT5.FILL_IOC())
        if fok and MT5.FILL_FOK() is not None:
            fills.append(MT5.FILL_FOK())
        if not fills and MT5.FILL_FOK() is not None:
            fills.append(MT5.FILL_FOK())

    return fills


def resolve(requested: str) -> Optional[SymbolSpec]:
    """Resolve a symbol to its full broker specification."""
    actual = _resolve_name(requested)
    if actual is None:
        log.warning(f"Symbol {requested} not available on this broker")
        return None

    info = MT5.symbol_info(actual)
    if info is None:
        return None

    d = info._asdict() if hasattr(info, "_asdict") else {}

    point = float(d.get("point", 0.01) or 0.01)
    tick_size = float(d.get("trade_tick_size", point) or point)
    tick_value = float(d.get("trade_tick_value", 0.0) or 0.0)
    contract_size = float(d.get("trade_contract_size", 100.0) or 100.0)
    currency_profit = str(d.get("currency_profit", "USD") or "USD")

    spec = SymbolSpec(
        requested=requested,
        actual=actual,
        digits=int(d.get("digits", 2)),
        point=point,
        tick_size=tick_size,
        tick_value=tick_value,
        volume_min=float(d.get("volume_min", 0.01) or 0.01),
        volume_max=float(d.get("volume_max", 100.0) or 100.0),
        volume_step=float(d.get("volume_step", 0.01) or 0.01),
        stops_level=int(d.get("trade_stops_level", 0) or 0),
        freeze_level=int(d.get("trade_freeze_level", 0) or 0),
        trade_exemode=int(d.get("trade_exemode", 0) or 0),
        filling_mode_bits=int(d.get("filling_mode", 0) or 0),
        filling_modes=_detect_fills(info),
        contract_size=contract_size,
        currency_profit=currency_profit,
    )

    log.info(
        f"[SYMBOL] {requested} -> {actual} | digits={spec.digits} point={spec.point} "
        f"tick_val={spec.tick_value} vol_min={spec.volume_min} "
        f"stops={spec.stops_level} fills={spec.filling_modes} "
        f"exemode={spec.trade_exemode} contract={contract_size}"
    )
    return spec
