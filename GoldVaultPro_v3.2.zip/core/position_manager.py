"""
GoldVault Pro v3.0 — Position Manager / Campaign Manager
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
8-layer exit hierarchy (per-ticket):
  0a. Hard USD stop (emergency safety net)
  0b. Time stop for scalps
  0c. Max hold time
  0d. Exit on weakness (momentum degradation)
  1.  Tiered giveback lock (% + USD from peak)
  2.  Break-even (ATR or USD trigger)
  3.  TP1 partial close (RR or USD trigger)
  4.  TP2 partial close + profit lock
  4b. TP3 partial (AGGRESSIVE profile)
  5.  ATR trailing (one-directional ratchet)

Campaign-level protection:
  - Basket giveback: close all if basket retreats too far from peak
  - Basket max loss: absolute USD loss limit per campaign
"""
from __future__ import annotations
import logging
import time
from typing import Dict, List, Optional

from .config import Config
from .execution import Executor
from .mt5 import MT5
from .types import (
    CampaignState, SetupType, Side, SymbolSpec, TradeRecord,
)
from . import indicators as ind

log = logging.getLogger("gvpro.pm")


class PositionManager:
    def __init__(self, cfg: Config, executor: Executor):
        self.cfg = cfg
        self.exec = executor
        self.trades: Dict[int, TradeRecord] = {}
        self._specs: Dict[str, SymbolSpec] = {}
        self._atr_cache: Dict[str, tuple] = {}
        self._basket_peaks: Dict[str, float] = {}   # campaign_key -> peak PnL

    def register_spec(self, spec: SymbolSpec) -> None:
        self._specs[spec.actual] = spec

    def register_trade(self, record: TradeRecord) -> None:
        self.trades[record.ticket] = record

    @property
    def basket_peaks(self) -> Dict[str, float]:
        return self._basket_peaks

    # ═════════════════════════════════════════════════════════
    #  MAIN MANAGEMENT LOOP
    # ═════════════════════════════════════════════════════════

    def manage_all(self) -> Dict[int, float]:
        """
        Manage all positions. Returns {ticket: realized_pnl} for closed positions.
        """
        positions = MT5.positions_get()
        seen: set = set()
        closed: Dict[int, float] = {}

        for pos in (positions or []):
            ticket = int(pos.ticket)
            seen.add(ticket)
            symbol = pos.symbol
            pnl = float(pos.profit)
            spec = self._specs.get(symbol)
            if spec is None:
                continue

            if ticket not in self.trades:
                if int(getattr(pos, "magic", 0)) == self.cfg.magic:
                    self._auto_register(pos)
                continue

            rec = self.trades[ticket]
            atr = self._get_atr(symbol)
            if atr <= 0:
                continue

            # Update peaks
            rec.peak_profit_usd = max(rec.peak_profit_usd, pnl)
            current_price = float(pos.price_current)
            if rec.side == Side.BUY:
                rec.peak_price = max(rec.peak_price, current_price)
            else:
                rec.peak_price = min(rec.peak_price or 999999, current_price)

            exit_cfg = self.cfg.exit_cfg(spec.requested)
            is_scalp = (rec.setup == SetupType.CRT_SCALP)

            # ── LAYER 0a: Hard USD stop ──────────────────────
            hard_stop = self.cfg.abs_max_risk(spec.requested) * self.cfg.hard_stop_multiplier
            if pnl < -hard_stop:
                log.warning(
                    f"[PM] #{ticket} HARD_STOP pnl=${pnl:.2f} < -${hard_stop:.2f}"
                )
                if self._close(pos, "HARD_STOP"):
                    closed[ticket] = pnl
                continue

            # ── LAYER 0b: Time stop for scalps ──────────────
            if is_scalp and pnl <= 0:
                max_scalp_min = self.cfg.time_stop_scalp_min(spec.requested)
                hold_min = (time.time() - rec.open_time) / 60.0
                if hold_min >= max_scalp_min:
                    log.info(
                        f"[PM] #{ticket} TIME_STOP_SCALP hold={hold_min:.0f}min pnl=${pnl:.2f}"
                    )
                    if self._close(pos, "TIME_STOP_SCALP"):
                        closed[ticket] = pnl
                    continue

            # ── LAYER 0c: Max hold time ──────────────────────
            max_hours = float(exit_cfg.get("max_hold_hours", 48))
            hold_h = (time.time() - rec.open_time) / 3600.0
            if hold_h > max_hours:
                if self._close(pos, "MAX_HOLD"):
                    closed[ticket] = pnl
                continue

            # ── LAYER 0d: Exit on weakness ───────────────────
            if self.cfg.weakness_enabled(spec.requested) and rec.peak_profit_usd > 0 and pnl > 0:
                if self._is_weak(pos, rec, spec, pnl):
                    log.info(f"[PM] #{ticket} EXIT_WEAKNESS pnl=${pnl:.2f} peak=${rec.peak_profit_usd:.2f}")
                    if self._close(pos, "WEAKNESS"):
                        closed[ticket] = pnl
                    continue

            # ── LAYER 1: Tiered giveback (% + USD absolute) ──
            if rec.peak_profit_usd > 0 and pnl > 0:
                floor = self._giveback_floor(spec.requested, rec.peak_profit_usd,
                                             self.cfg.giveback_pct, self.cfg.giveback_usd)
                if rec.risk_usd > 0 and rec.peak_profit_usd > rec.risk_usd * 0.5:
                    if pnl <= floor:
                        log.info(
                            f"[PM] #{ticket} GIVEBACK peak=${rec.peak_profit_usd:.2f} "
                            f"now=${pnl:.2f} floor=${floor:.2f}"
                        )
                        if self._close(pos, "GIVEBACK"):
                            closed[ticket] = pnl
                        continue

            # ── LAYER 2: Break-even ──────────────────────────
            if not rec.be_done:
                be_atr_mult = float(exit_cfg.get("breakeven_atr_mult", 0.8))
                be_usd_thresh = self.cfg.be_usd(spec.requested)
                entry = rec.entry_price
                advance = ((current_price - entry) if rec.side == Side.BUY
                           else (entry - current_price))
                atr_trigger = advance >= atr * be_atr_mult
                usd_trigger = be_usd_thresh > 0 and pnl >= be_usd_thresh
                if atr_trigger or usd_trigger:
                    new_sl = self._calc_be_sl(pos, spec, entry, atr)
                    if new_sl is not None:
                        ok = self.exec.modify_sl_tp(spec, ticket, new_sl, float(pos.tp or 0))
                        if ok.ok:
                            rec.be_done = True
                            rec.be_price = new_sl
                            rec.sl = new_sl
                            src = "USD" if (usd_trigger and not atr_trigger) else "ATR"
                            log.info(f"[PM] #{ticket} BE({src}) sl={new_sl:.5f} pnl=${pnl:.2f}")

            # ── LAYER 3: TP1 partial ─────────────────────────
            if not rec.partial1_done and rec.risk_usd > 0:
                p1_usd = self.cfg.partial1_usd(spec.requested)
                target_rr = rec.risk_usd * self.cfg.partial1_rr
                if pnl >= target_rr or (p1_usd > 0 and pnl >= p1_usd):
                    pct = self.cfg.partial1_pct / 100.0
                    vol = self._safe_partial_vol(spec, rec.volume_current, pct)
                    if vol > 0:
                        ok = self.exec.partial_close(pos, vol, "TP1")
                        if ok.ok:
                            rec.partial1_done = True
                            rec.volume_current = max(0.0, rec.volume_current - vol)
                            rec.closed_pnl += pnl * (vol / max(float(pos.volume), 1e-10))
                            log.info(f"[PM] #{ticket} TP1 vol={vol:.4f} pnl=${pnl:.2f}")

            # ── LAYER 4: TP2 partial + profit lock ───────────
            if rec.partial1_done and not rec.partial2_done and rec.risk_usd > 0:
                p2_usd = self.cfg.partial2_usd(spec.requested)
                target_rr = rec.risk_usd * self.cfg.partial2_rr
                if pnl >= target_rr or (p2_usd > 0 and pnl >= p2_usd):
                    pct = self.cfg.partial2_pct / 100.0
                    vol = self._safe_partial_vol(spec, rec.volume_current, pct)
                    if vol > 0:
                        ok = self.exec.partial_close(pos, vol, "TP2")
                        if ok.ok:
                            rec.partial2_done = True
                            rec.volume_current = max(0.0, rec.volume_current - vol)
                            rec.closed_pnl += pnl * (vol / max(float(pos.volume), 1e-10))
                            log.info(f"[PM] #{ticket} TP2 vol={vol:.4f} pnl=${pnl:.2f}")
                            if self.cfg.lock_after_partial2(spec.requested):
                                self._profit_lock(pos, spec, atr)

            # ── LAYER 4b: TP3 (AGGRESSIVE) ───────────────────
            if (rec.partial2_done and not rec.partial3_done
                    and rec.risk_usd > 0 and self.cfg.partial3_pct > 0):
                target = rec.risk_usd * self.cfg.partial3_rr
                if pnl >= target:
                    pct = self.cfg.partial3_pct / 100.0
                    vol = self._safe_partial_vol(spec, rec.volume_current, pct)
                    if vol > 0:
                        ok = self.exec.partial_close(pos, vol, "TP3")
                        if ok.ok:
                            rec.partial3_done = True
                            rec.volume_current = max(0.0, rec.volume_current - vol)
                            rec.closed_pnl += pnl * (vol / max(float(pos.volume), 1e-10))
                            log.info(f"[PM] #{ticket} TP3 vol={vol:.4f} pnl=${pnl:.2f}")

            # ── LAYER 5: ATR Trailing ────────────────────────
            trail_start = self.cfg.trail_start_rr
            trail_atr = self.cfg.trail_atr_mult
            if rec.risk_usd > 0:
                if rec.side == Side.BUY:
                    adv_atr = (current_price - rec.entry_price) / max(atr, 1e-10)
                else:
                    adv_atr = (rec.entry_price - current_price) / max(atr, 1e-10)
                if adv_atr >= trail_start:
                    trail_dist = atr * trail_atr
                    if rec.side == Side.BUY:
                        new_sl = current_price - trail_dist
                        cur_sl = float(pos.sl or 0)
                        if new_sl > cur_sl + spec.point:
                            ok = self.exec.modify_sl_tp(spec, ticket, new_sl, float(pos.tp or 0))
                            if ok.ok:
                                rec.trail_active = True; rec.trail_sl = new_sl; rec.sl = new_sl
                    else:
                        new_sl = current_price + trail_dist
                        cur_sl = float(pos.sl or 999999)
                        if new_sl < cur_sl - spec.point:
                            ok = self.exec.modify_sl_tp(spec, ticket, new_sl, float(pos.tp or 0))
                            if ok.ok:
                                rec.trail_active = True; rec.trail_sl = new_sl; rec.sl = new_sl

        # ── CAMPAIGN-LEVEL PROTECTION ─────────────────────────
        basket_closed = self._manage_campaigns()
        for t, p in basket_closed.items():
            closed[t] = p

        self._cleanup(seen)
        return closed

    # ═════════════════════════════════════════════════════════
    #  CAMPAIGN PROTECTION
    # ═════════════════════════════════════════════════════════

    def _manage_campaigns(self) -> Dict[int, float]:
        """
        Basket-level protection: giveback and max-loss for multi-position campaigns.
        Solo positions are protected by per-ticket giveback in manage_all().
        """
        closed: Dict[int, float] = {}
        campaigns: Dict[str, CampaignState] = {}

        for ticket, rec in self.trades.items():
            key = rec.campaign_key or f"{rec.symbol}:{rec.side.value}"
            if key not in campaigns:
                s = Side.BUY if ":BUY" in key else Side.SELL
                sym = key.split(":")[0]
                campaigns[key] = CampaignState(symbol=sym, side=s)
            c = campaigns[key]
            c.tickets.append(ticket)
            c.count += 1
            c.total_risk_usd += rec.risk_usd

        for key, camp in campaigns.items():
            if camp.count < 2:
                continue  # per-ticket giveback handles solo positions

            positions = MT5.positions_get(symbol=camp.symbol)
            basket_pnl = 0.0
            basket_pos = []
            for pos in (positions or []):
                p_side = Side.BUY if int(pos.type) == 0 else Side.SELL
                if p_side == camp.side:
                    basket_pnl += float(pos.profit)
                    basket_pos.append(pos)

            # Update persistent peak
            prev_peak = self._basket_peaks.get(key, 0.0)
            new_peak = max(prev_peak, basket_pnl)
            self._basket_peaks[key] = new_peak

            sym_req = camp.symbol  # use actual for config lookup
            # resolve to requested symbol name (cfg keys on requested)
            spec = self._specs.get(camp.symbol)
            req_sym = spec.requested if spec else camp.symbol

            # Gate 1: basket absolute max loss
            max_loss = self.cfg.campaign_basket_max_loss_usd(req_sym)
            if basket_pnl < -max_loss:
                log.warning(
                    f"[PM] CAMPAIGN {key} MAX_LOSS basket=${basket_pnl:.2f} < -${max_loss:.2f}"
                )
                for pos in basket_pos:
                    t = int(pos.ticket)
                    if self._close(pos, "CAMPAIGN_MAX_LOSS"):
                        closed[t] = float(pos.profit)
                self._basket_peaks.pop(key, None)
                continue

            # Gate 2: basket giveback from peak
            gb_pct = self.cfg.campaign_basket_giveback_pct(req_sym) / 100.0
            if new_peak > camp.total_risk_usd * 0.5:
                floor = new_peak * (1.0 - gb_pct)
                if basket_pnl < floor and basket_pnl < 0:
                    log.info(
                        f"[PM] CAMPAIGN {key} GIVEBACK peak=${new_peak:.2f} "
                        f"now=${basket_pnl:.2f} floor=${floor:.2f}"
                    )
                    for pos in basket_pos:
                        t = int(pos.ticket)
                        if self._close(pos, "CAMPAIGN_GIVEBACK"):
                            closed[t] = float(pos.profit)
                    self._basket_peaks.pop(key, None)

        return closed

    # ═════════════════════════════════════════════════════════
    #  CAMPAIGN STATE BUILDER (for engine use)
    # ═════════════════════════════════════════════════════════

    def build_campaign(self, symbol: str, side: Side) -> CampaignState:
        """Build current campaign state for a symbol+side from live positions."""
        positions = MT5.positions_get(symbol=symbol)
        camp = CampaignState(symbol=symbol, side=side)
        total_vol_price = 0.0
        all_be = True

        for pos in (positions or []):
            p_side = Side.BUY if int(pos.type) == 0 else Side.SELL
            if p_side != side:
                continue
            ticket = int(pos.ticket)
            camp.tickets.append(ticket)
            camp.total_volume += float(pos.volume)
            camp.net_pnl += float(pos.profit)
            total_vol_price += float(pos.volume) * float(pos.price_open)
            camp.count += 1

            rec = self.trades.get(ticket)
            if rec:
                camp.total_risk_usd += rec.risk_usd
                if not rec.be_done:
                    all_be = False
                if rec.is_add is False and rec.be_done and float(pos.profit) > 0:
                    camp.primary_protected = True
            else:
                all_be = False

        if camp.total_volume > 0:
            camp.avg_entry = total_vol_price / camp.total_volume
        camp.all_protected = all_be and camp.count > 0

        key = camp.key
        prev_peak = self._basket_peaks.get(key, 0.0)
        camp.peak_pnl = max(prev_peak, camp.net_pnl)
        self._basket_peaks[key] = camp.peak_pnl

        return camp

    # ═════════════════════════════════════════════════════════
    #  HELPERS
    # ═════════════════════════════════════════════════════════

    def _giveback_floor(self, symbol: str, peak: float,
                        default_pct: float, default_usd: float) -> float:
        """Compute the giveback floor using tiered thresholds."""
        t1_pnl = self.cfg.giveback_tier1_pnl(symbol)
        t1_pct = self.cfg.giveback_tier1_pct(symbol) / 100.0
        t2_pnl = self.cfg.giveback_tier2_pnl(symbol)
        t2_pct = self.cfg.giveback_tier2_pct(symbol) / 100.0

        if peak >= t2_pnl:
            pct = t2_pct
        elif peak >= t1_pnl:
            pct = t1_pct
        else:
            pct = default_pct / 100.0

        floor_pct = peak * (1.0 - pct)
        floor_usd = peak - default_usd
        return max(max(floor_pct, floor_usd), 0.0)

    def _is_weak(self, pos, rec: TradeRecord, spec: SymbolSpec, pnl: float) -> bool:
        """
        Detect momentum degradation:
        - price rejected significant portion of the last N bars' move
        - position still has decent profit to protect
        """
        if rec.peak_profit_usd < rec.risk_usd * 0.5:
            return False  # too early to exit on weakness
        lookback = self.cfg.weakness_lookback(spec.requested)
        rej_thresh = self.cfg.weakness_rejection_pct(spec.requested) / 100.0
        symbol = pos.symbol
        rates = MT5.get_rates(symbol, "M15", lookback + 2)
        if not rates or len(rates) < lookback + 1:
            return False
        # Measure how much of the last-bar move was rejected
        last = rates[-1]
        high = float(last.get("high", 0))
        low = float(last.get("low", 0))
        close_ = float(last.get("close", 0))
        bar_range = high - low
        if bar_range <= 0:
            return False
        if rec.side == Side.BUY:
            # Bearish rejection: close near low after long wick
            rejection = (high - close_) / bar_range
        else:
            rejection = (close_ - low) / bar_range
        # Only flag if profit meaningfully retreated from peak
        profit_retreat = (rec.peak_profit_usd - pnl) / max(rec.peak_profit_usd, 1e-10)
        if rejection > rej_thresh and profit_retreat > 0.30 and not rec.weakness_warned:
            rec.weakness_warned = True
            log.info(
                f"[PM] #{int(pos.ticket)} WEAKNESS detected "
                f"rejection={rejection:.0%} retreat={profit_retreat:.0%}"
            )
            return True
        return False

    def _profit_lock(self, pos, spec: SymbolSpec, atr: float) -> None:
        """After TP2: move SL to lock guaranteed profit (entry + lock_atr_mult * ATR)."""
        tick = MT5.symbol_info_tick(spec.actual)
        if tick is None:
            return
        lock_mult = self.cfg.lock_atr_mult(spec.requested)
        min_off = max(spec.stops_level + spec.freeze_level + 4, 8) * spec.point
        lock_dist = max(atr * lock_mult, min_off)
        is_buy = int(pos.type) == 0
        if is_buy:
            new_sl = float(pos.price_open) + lock_dist
            new_sl = min(new_sl, float(tick.bid) - min_off)
            cur_sl = float(pos.sl or 0)
            if new_sl > cur_sl + spec.point:
                ok = self.exec.modify_sl_tp(spec, int(pos.ticket), new_sl, float(pos.tp or 0))
                if ok.ok:
                    log.info(f"[PM] #{pos.ticket} PROFIT_LOCK sl={new_sl:.5f}")
        else:
            new_sl = float(pos.price_open) - lock_dist
            new_sl = max(new_sl, float(tick.ask) + min_off)
            cur_sl = float(pos.sl or 999999)
            if new_sl < cur_sl - spec.point:
                ok = self.exec.modify_sl_tp(spec, int(pos.ticket), new_sl, float(pos.tp or 0))
                if ok.ok:
                    log.info(f"[PM] #{pos.ticket} PROFIT_LOCK sl={new_sl:.5f}")

    def _calc_be_sl(self, pos, spec: SymbolSpec, entry: float,
                    atr: float) -> Optional[float]:
        tick = MT5.symbol_info_tick(spec.actual)
        if tick is None:
            return None
        min_off = max(spec.stops_level + spec.freeze_level + 4, 8) * spec.point
        lock = atr * 0.15
        is_buy = int(pos.type) == 0
        if is_buy:
            sl = max(entry + lock, entry + 2 * spec.point)
            sl = min(sl, tick.bid - min_off)
        else:
            sl = min(entry - lock, entry - 2 * spec.point)
            sl = max(sl, tick.ask + min_off)
        return sl

    def _safe_partial_vol(self, spec: SymbolSpec, current_vol: float, pct: float) -> float:
        vol = round(current_vol * pct, 8)
        step = spec.volume_step
        vol = max(spec.volume_min, int(vol / step) * step)
        remaining = current_vol - vol
        if remaining < spec.volume_min:
            vol = current_vol  # close all
        return min(vol, current_vol)

    def _close(self, pos, reason: str) -> bool:
        result = self.exec.close_position(pos, reason)
        if result.ok:
            log.info(f"[PM] #{pos.ticket} CLOSED reason={reason} pnl={pos.profit:.2f}")
        return result.ok

    def _get_atr(self, symbol: str) -> float:
        now = time.time()
        cached = self._atr_cache.get(symbol)
        if cached and now - cached[1] < 60:
            return cached[0]
        rates = MT5.get_rates(symbol, "M15", 20)
        if rates and len(rates) >= 15:
            from . import indicators as ind_mod
            h = [float(r["high"]) for r in rates]
            l = [float(r["low"]) for r in rates]
            c = [float(r["close"]) for r in rates]
            val = ind_mod.atr(h, l, c, 14)
            self._atr_cache[symbol] = (val, now)
            return val
        return 0.0

    def _auto_register(self, pos) -> None:
        """Auto-register a position we didn't open (e.g. after restart)."""
        ticket = int(pos.ticket)
        sym = pos.symbol
        p_side = Side.BUY if int(pos.type) == 0 else Side.SELL
        spec = self._specs.get(sym)
        vol = float(pos.volume)
        rec = TradeRecord(
            ticket=ticket, symbol=sym, side=p_side,
            setup=SetupType.TREND_CONTINUATION,
            volume_initial=vol, volume_current=vol,
            entry_price=float(pos.price_open),
            sl=float(pos.sl or 0), tp=float(pos.tp or 0),
            risk_usd=0.0, score=0.0,
            open_time=float(getattr(pos, "time", time.time())),
            campaign_key=f"{sym}:{p_side.value}",
        )
        self.trades[ticket] = rec
        log.info(f"[PM] Auto-registered #{ticket} {sym} {p_side.value}")

    def _cleanup(self, seen: set) -> None:
        for ticket in list(self.trades.keys()):
            if ticket not in seen:
                rec = self.trades.pop(ticket)
                log.info(f"[PM] Unregistered #{ticket} {rec.symbol} (position closed)")
