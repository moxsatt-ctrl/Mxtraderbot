"""
GoldVault Pro v3.0 — Core Data Types
5 strategy types, campaign state, extended trade record.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional


class Side(Enum):
    BUY = "BUY"
    SELL = "SELL"


class SetupType(Enum):
    TREND_CONTINUATION = "TREND_CONTINUATION"
    BREAKOUT_EXPANSION = "BREAKOUT_EXPANSION"
    PULLBACK_TO_TREND  = "PULLBACK_TO_TREND"
    CRT_SCALP          = "CRT_SCALP"
    MANUAL_STYLE       = "MANUAL_STYLE"


class Regime(Enum):
    TREND_UP   = "TREND_UP"
    TREND_DOWN = "TREND_DOWN"
    RANGE      = "RANGE"
    VOLATILE   = "VOLATILE"
    BREAKOUT   = "BREAKOUT"


class Action(Enum):
    OPEN = "OPEN"
    ADD  = "ADD"
    WAIT = "WAIT"


class Profile(Enum):
    CONSERVATIVE = "CONSERVATIVE"
    BALANCED     = "BALANCED"
    AGGRESSIVE   = "AGGRESSIVE"


# ── Broker / Symbol ──────────────────────────────────────────

@dataclass
class SymbolSpec:
    requested: str
    actual: str
    digits: int
    point: float
    tick_size: float
    tick_value: float
    volume_min: float
    volume_max: float
    volume_step: float
    stops_level: int
    freeze_level: int
    trade_exemode: int = 0
    filling_mode_bits: int = 0
    filling_modes: List[int] = field(default_factory=list)
    contract_size: float = 100.0
    currency_profit: str = "USD"


# ── Indicators ───────────────────────────────────────────────

@dataclass
class IndicatorSet:
    ema_fast: float = 0.0
    ema_slow: float = 0.0
    ema_trend: float = 0.0
    ema_bias: float = 0.0
    rsi: float = 50.0
    adx: float = 15.0
    plus_di: float = 0.0
    minus_di: float = 0.0
    macd_line: float = 0.0
    macd_signal: float = 0.0
    macd_hist: float = 0.0
    atr: float = 0.0
    bb_upper: float = 0.0
    bb_middle: float = 0.0
    bb_lower: float = 0.0
    donchian_high: float = 0.0
    donchian_low: float = 0.0
    zscore: float = 0.0
    volume_sma: float = 0.0
    momentum: float = 0.0       # net price change last 3 bars / ATR
    compression: float = 1.0    # recent ATR / longer ATR (< 1 = compressed)


# ── Market ───────────────────────────────────────────────────

@dataclass
class MarketContext:
    symbol: str
    bid: float
    ask: float
    spread_points: float
    spread_pct_of_atr: float
    regime: Regime
    entry_tf: IndicatorSet
    trend_tf: IndicatorSet
    bias_tf: IndicatorSet
    atr_value: float
    atr_points: float
    timestamp: float = 0.0
    recent_closes: List[float] = field(default_factory=list)  # last 20 M15 closes


# ── Signal ───────────────────────────────────────────────────

@dataclass
class Signal:
    symbol: str
    action: Action
    side: Optional[Side] = None
    setup: Optional[SetupType] = None
    score: float = 0.0
    sl_price: float = 0.0
    tp_price: float = 0.0
    entry_price: float = 0.0
    rr_ratio: float = 0.0
    reasons: List[str] = field(default_factory=list)
    is_add: bool = False


# ── Execution ────────────────────────────────────────────────

@dataclass
class ExecResult:
    ok: bool
    retcode: Optional[int] = None
    comment: str = ""
    order: Optional[int] = None
    deal: Optional[int] = None
    volume: float = 0.0
    price: float = 0.0


# ── Risk Verification ────────────────────────────────────────

@dataclass
class RiskVerification:
    """Triple-verified monetary risk before any trade opens."""
    broker_calc_usd: Optional[float] = None
    tick_math_usd: Optional[float] = None
    contract_math_usd: Optional[float] = None
    final_risk_usd: float = 0.0
    volume_final: float = 0.0
    method_used: str = ""
    discrepancy_ratio: float = 0.0
    passed: bool = False
    reject_reason: str = ""


# ── Trade Record ─────────────────────────────────────────────

@dataclass
class TradeRecord:
    ticket: int
    symbol: str
    side: Side
    setup: SetupType
    volume_initial: float
    volume_current: float
    entry_price: float
    sl: float
    tp: float
    risk_usd: float
    score: float
    open_time: float
    atr_at_open: float = 0.0
    peak_profit_usd: float = 0.0
    peak_price: float = 0.0
    partial1_done: bool = False
    partial2_done: bool = False
    partial3_done: bool = False
    be_done: bool = False
    be_price: float = 0.0
    lock_done: bool = False
    trail_active: bool = False
    trail_sl: float = 0.0
    is_add: bool = False
    parent_ticket: int = 0
    closed_pnl: float = 0.0     # sum of partial realized PnL
    campaign_key: str = ""       # e.g. "XAUUSD:BUY"
    weakness_warned: bool = False


# ── Campaign State ────────────────────────────────────────────

@dataclass
class CampaignState:
    """Aggregated state of all open positions for one symbol+side ('campaign')."""
    symbol: str
    side: Side
    tickets: List[int] = field(default_factory=list)
    total_volume: float = 0.0
    total_risk_usd: float = 0.0
    net_pnl: float = 0.0
    avg_entry: float = 0.0
    peak_pnl: float = 0.0
    count: int = 0
    all_protected: bool = False     # all positions at BE+
    primary_protected: bool = False  # first position at BE+

    @property
    def key(self) -> str:
        return f"{self.symbol}:{self.side.value}"

    @property
    def all_at_be(self) -> bool:
        return self.all_protected


# ── Daily ────────────────────────────────────────────────────

@dataclass
class DailyStats:
    date: str
    start_equity: float
    current_equity: float
    trades_opened: int = 0
    trades_closed: int = 0
    wins: int = 0
    losses: int = 0
    gross_profit: float = 0.0
    gross_loss: float = 0.0
    max_drawdown: float = 0.0
    is_locked: bool = False
    lock_reason: str = ""
