"""
GoldVault Pro v3.0 — Main Engine
"""
from __future__ import annotations
import logging
import signal
import sys
import time
from collections import defaultdict
from typing import Dict

from .config import Config
from .execution import Executor
from .journal import Journal
from .market import MarketAnalyzer
from .mt5 import MT5
from .position_manager import PositionManager
from .risk import RiskEngine
from .strategy import StrategyEngine
from .symbols import resolve as resolve_symbol
from .types import Action, Side, Signal, SymbolSpec, TradeRecord

log = logging.getLogger("gvpro")


class Engine:
    def __init__(self, config_path: str = None):
        self.cfg = Config(config_path)
        self.market = MarketAnalyzer(self.cfg)
        self.strategy = StrategyEngine(self.cfg)
        self.risk = RiskEngine(self.cfg)
        self.executor = Executor(self.cfg)
        self.pm = PositionManager(self.cfg, self.executor)
        self.journal = Journal(self.cfg)

        self._specs: Dict[str, SymbolSpec] = {}
        self._last_open_ts: Dict[str, float] = defaultdict(float)
        self._last_entry_price: Dict[str, float] = {}
        self._last_loss_ts: Dict[str, float] = defaultdict(float)
        self._log_cache: Dict[str, tuple] = {}
        self._last_learn_ts: float = 0.0
        self._running = True

    def start(self) -> None:
        self._setup_logging()
        self._setup_signals()

        log.info("=" * 60)
        log.info("  GOLDVAULT PRO v3.0 — Investment Manager")
        log.info(f"  Profile: {self.cfg.profile_name}")
        log.info(f"  Symbols: {self.cfg.symbols}")
        log.info(f"  Risk/trade: {self.cfg.risk_pct}%  Pyramid: {'ON' if self.cfg.pyramid_enabled else 'OFF'}")
        log.info("=" * 60)

        if not MT5.available():
            log.error("MetaTrader5 not installed."); return
        if not MT5.init():
            log.error("Cannot connect to MT5."); return

        for sym in self.cfg.symbols:
            spec = resolve_symbol(sym)
            if spec:
                self._specs[sym] = spec
                self.pm.register_spec(spec)
            else:
                log.warning(f"{sym} not available")

        if not self._specs:
            log.error("No symbols. Exiting."); MT5.shutdown(); return

        self.risk.init_daily()
        log.info(f"Ready. {len(self._specs)} symbols.")
        self._loop()

    def _loop(self) -> None:
        try:
            while self._running:
                t0 = time.time()
                self.risk.init_daily()
                session_ok, session_msg = self.risk.session_allowed()

                closed = self.pm.manage_all()
                for pnl in closed.values():
                    self.risk.record_close(pnl)

                if self.risk.daily.is_locked:
                    self._tlog("circuit", f"[ENGINE] LOCKED: {self.risk.daily.lock_reason}", 60)
                    time.sleep(self.cfg.loop_sec); continue

                if not session_ok:
                    self._tlog("session", f"[ENGINE] {session_msg}", 120)
                    time.sleep(self.cfg.loop_sec); continue

                for sym, spec in self._specs.items():
                    try:
                        self._eval(spec)
                    except Exception as e:
                        log.error(f"Error {sym}: {e}", exc_info=True)

                if time.time() - self._last_learn_ts > 3600:
                    self.journal.update_setup_rankings()
                    self._last_learn_ts = time.time()

                time.sleep(max(0.1, self.cfg.loop_sec - (time.time() - t0)))

        except KeyboardInterrupt:
            log.info("Shutdown by user")
        except Exception as e:
            log.critical(f"Fatal: {e}", exc_info=True)
        finally:
            self._shutdown()

    def _eval(self, spec: SymbolSpec) -> None:
        sym = spec.actual
        now = time.time()

        ctx = self.market.analyze(spec)
        if ctx is None:
            return

        self._tlog(
            f"brain:{sym}",
            f"[BRAIN] {sym} {ctx.regime.value} ADX={ctx.entry_tf.adx:.1f} "
            f"RSI={ctx.entry_tf.rsi:.1f} Z={ctx.entry_tf.zscore:.2f} "
            f"ATR={ctx.atr_value:.2f} Spd={ctx.spread_pct_of_atr:.1f}%",
            30,
        )

        # Build baskets for both sides so strategy can use them
        peaks = self.pm.basket_peaks
        basket_buy = self.risk.build_basket(spec, Side.BUY, self.pm.trades, peaks)
        basket_sell = self.risk.build_basket(spec, Side.SELL, self.pm.trades, peaks)

        # Pass relevant basket to strategy
        # Strategy will decide side; pass whichever has positions (or None)
        hint_basket = basket_buy if basket_buy.count > 0 else (
            basket_sell if basket_sell.count > 0 else None
        )
        signal = self.strategy.evaluate(ctx, spec, campaign=hint_basket)

        if signal.action == Action.WAIT:
            self._tlog(f"wait:{sym}", f"[WAIT] {sym} {';'.join(signal.reasons)}", 45)
            return

        # Select correct basket for chosen side
        basket = basket_buy if signal.side == Side.BUY else basket_sell

        # Cooldown gates
        if now - self._last_open_ts.get(sym, 0) < self.cfg.cd_same_symbol:
            return
        if now - self._last_loss_ts.get(sym, 0) < self.cfg.cd_after_loss:
            return

        # Distance gate
        min_dist = ctx.atr_value * self.cfg.reentry_min_dist_atr(spec.requested)
        key = f"{sym}:{signal.side.value}"
        if key in self._last_entry_price:
            cur = ctx.ask if signal.side == Side.BUY else ctx.bid
            if abs(cur - self._last_entry_price[key]) < min_dist:
                return

        # Is this a pyramid add?
        is_add = signal.is_add or (signal.action == Action.ADD) or basket.count > 0

        if is_add:
            ok, reason = self.risk.can_pyramid(spec, signal, basket, ctx.atr_value)
            if not ok:
                self._tlog(f"pyr:{sym}", f"[PYRAMID] {sym} blocked: {reason}", 30)
                return
        else:
            ok, reason = self.risk.can_trade(spec, signal, basket)
            if not ok:
                self._tlog(f"risk:{sym}", f"[RISK] {sym} blocked: {reason}", 20)
                return

        v = self.risk.size_and_verify(spec, signal, is_add=is_add)
        if not v.passed:
            log.warning(f"[RISK] {sym} REJECTED: {v.reject_reason}")
            return

        volume = v.volume_final

        result = self.executor.send_market(
            spec, signal.side, volume, signal.sl_price, signal.tp_price
        )

        if result.ok:
            ticket = int(result.order or result.deal or 0)
            # Fallback: find newest position with our magic
            if ticket == 0 or ticket in self.pm.trades:
                time.sleep(0.1)
                positions = MT5.positions_get(symbol=sym)
                our = [p for p in (positions or [])
                       if int(getattr(p, "magic", 0)) == self.cfg.magic
                       and int(p.ticket) not in self.pm.trades]
                if our:
                    newest = max(our, key=lambda p: (
                        float(getattr(p, "time_msc", 0) or getattr(p, "time", 0))
                    ))
                    ticket = int(newest.ticket)

            log.info(
                f"[{'ADD' if is_add else 'OPEN'}] {signal.setup.value} {sym} "
                f"{signal.side.value} vol={volume:.4f} risk=${v.final_risk_usd:.2f} "
                f"sl={signal.sl_price:.2f} tp={signal.tp_price:.2f} "
                f"rr={signal.rr_ratio:.1f} score={signal.score:.0f} ticket={ticket}"
            )

            self._last_open_ts[sym] = now
            self._last_entry_price[key] = signal.entry_price
            self.risk.record_open()

            if ticket > 0:
                rec = TradeRecord(
                    ticket=ticket, symbol=sym, side=signal.side,
                    setup=signal.setup, volume_initial=volume,
                    volume_current=volume, entry_price=signal.entry_price,
                    sl=signal.sl_price, tp=signal.tp_price,
                    risk_usd=v.final_risk_usd, score=signal.score,
                    open_time=now, atr_at_open=ctx.atr_value,
                    peak_price=signal.entry_price, is_add=is_add,
                    parent_ticket=basket.tickets[0] if is_add and basket.tickets else 0,
                )
                self.pm.register_trade(rec)

            self.journal.log_open(
                ticket=ticket, symbol=sym, side=signal.side.value,
                setup=signal.setup.value, volume=volume,
                entry=signal.entry_price, sl=signal.sl_price,
                tp=signal.tp_price, risk_usd=v.final_risk_usd,
                risk_method=v.method_used, score=signal.score,
                rr=signal.rr_ratio, regime=ctx.regime.value,
                adx=ctx.entry_tf.adx, rsi=ctx.entry_tf.rsi,
                atr=ctx.atr_value, zscore=ctx.entry_tf.zscore,
                spread_pct=ctx.spread_pct_of_atr,
                reasons=signal.reasons, is_add=is_add,
            )
        else:
            log.warning(
                f"[FAIL] {sym} {signal.side.value} ret={result.retcode} "
                f"cmt={result.comment}"
            )

    def _tlog(self, key: str, msg: str, interval: float = 30) -> None:
        now = time.time()
        cached = self._log_cache.get(key)
        if cached and cached[0] == msg and now - cached[1] < interval:
            return
        log.info(msg)
        self._log_cache[key] = (msg, now)

    def _setup_logging(self) -> None:
        from pathlib import Path
        Path("state").mkdir(exist_ok=True)
        level = getattr(logging, self.cfg.log_level.upper(), logging.INFO)
        logging.basicConfig(
            level=level,
            format="[%(asctime)s] %(levelname)-7s %(name)s — %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S",
            handlers=[
                logging.StreamHandler(sys.stdout),
                logging.FileHandler("state/goldvault.log", encoding="utf-8"),
            ],
        )

    def _setup_signals(self) -> None:
        def handler(signum, frame): self._running = False
        signal.signal(signal.SIGINT, handler)
        signal.signal(signal.SIGTERM, handler)

    def _shutdown(self) -> None:
        log.info("Shutting down...")
        d = self.risk.daily
        self.journal.save_daily(
            d.date, d.start_equity, MT5.equity(),
            d.trades_opened, d.trades_closed, d.wins, d.losses,
            d.gross_profit, d.gross_loss, self.risk._daily_dd_pct(),
        )
        self.journal.update_setup_rankings()
        MT5.shutdown()
        log.info("GoldVault Pro stopped.")
