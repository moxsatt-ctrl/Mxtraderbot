"""
GoldVault Pro v2.1 — Risk Engine (Prioridad 1)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Triple monetary validation:
  1. MT5 order_calc_profit (broker-side)
  2. Tick-math (tick_value × ticks × volume)
  3. Contract-math (contract_size × dist / point × point_value)

Volume clamp absoluto por símbolo.
No abre si discrepancia entre métodos > umbral.
"""
from __future__ import annotations
import logging
import time
from datetime import datetime, timezone
from typing import Optional, Tuple

from .config import Config
from .mt5 import MT5
from .types import (
    CampaignState as BasketState, DailyStats, RiskVerification,
    Side, Signal, SymbolSpec, TradeRecord,
)

log = logging.getLogger("gvpro.risk")


class RiskEngine:
    def __init__(self, cfg: Config):
        self.cfg = cfg
        self.daily = DailyStats(date=self._today(), start_equity=0.0, current_equity=0.0)
        self._initialized = False

    # ═════════════════════════════════════════════════════════
    #  DAILY RESET
    # ═════════════════════════════════════════════════════════

    def init_daily(self) -> None:
        today = self._today()
        equity = MT5.equity()
        if not self._initialized or self.daily.date != today:
            self.daily = DailyStats(date=today, start_equity=equity, current_equity=equity)
            self._initialized = True
            log.info(f"[RISK] Daily reset: {today} equity={equity:.2f} profile={self.cfg.profile_name}")

    # ═════════════════════════════════════════════════════════
    #  PRE-TRADE GATE (all checks before opening)
    # ═════════════════════════════════════════════════════════

    def can_trade(self, spec: SymbolSpec, signal: Signal,
                  basket: Optional[BasketState] = None) -> Tuple[bool, str]:
        """Full pre-trade risk gate. Returns (allowed, reason)."""
        self.init_daily()
        self.daily.current_equity = MT5.equity()

        # 1. Circuit breaker: daily DD
        dd = self._daily_dd_pct()
        if dd >= self.cfg.max_daily_dd_pct:
            self.daily.is_locked = True
            self.daily.lock_reason = f"daily_dd={dd:.1f}%"
            return False, f"CIRCUIT_BREAKER daily_dd={dd:.1f}%"

        # 2. Circuit breaker: total DD
        tdd = self._total_dd_pct()
        if tdd >= self.cfg.max_total_dd_pct:
            self.daily.is_locked = True
            self.daily.lock_reason = f"total_dd={tdd:.1f}%"
            return False, f"CIRCUIT_BREAKER total_dd={tdd:.1f}%"

        # 3. Locked
        if self.daily.is_locked:
            return False, f"locked({self.daily.lock_reason})"

        # 4. Free margin
        ml = MT5.margin_level()
        if ml < self.cfg.min_free_margin_pct:
            return False, f"low_margin({ml:.0f}%)"

        # 5. Position limits
        all_pos = MT5.positions_get()
        sym_pos = [p for p in all_pos if p.symbol == spec.actual]
        if len(all_pos) >= self.cfg.max_total_pos:
            return False, f"max_total_pos({len(all_pos)})"
        if len(sym_pos) >= self.cfg.max_pos_per_symbol:
            return False, f"max_symbol_pos({len(sym_pos)})"

        # 6. No opposite side
        if signal.side:
            for p in sym_pos:
                p_side = "BUY" if int(p.type) == 0 else "SELL"
                if p_side != signal.side.value:
                    return False, "opposite_side_open"

        # 7. Basket risk cap
        if basket and basket.count > 0:
            equity = max(MT5.equity(), 1.0)
            basket_risk_pct = basket.total_risk_usd / equity * 100.0
            if basket_risk_pct >= self.cfg.max_basket_risk_pct:
                return False, f"basket_risk({basket_risk_pct:.1f}%>={self.cfg.max_basket_risk_pct}%)"

        return True, "OK"

    # ═════════════════════════════════════════════════════════
    #  PYRAMID GATE (extra checks for adds)
    # ═════════════════════════════════════════════════════════

    def can_pyramid(self, spec: SymbolSpec, signal: Signal,
                    basket: BasketState, ctx_atr: float) -> Tuple[bool, str]:
        """Extra checks for pyramid add. Includes base can_trade checks."""
        ok, reason = self.can_trade(spec, signal, basket)
        if not ok:
            return False, reason

        if not self.cfg.pyramid_enabled:
            return False, "pyramid_disabled"

        add_count = basket.count - 1  # minus the primary
        if add_count >= self.cfg.pyramid_max_adds:
            return False, f"pyramid_max_adds({add_count})"

        # Require all existing at BE
        if self.cfg.pyramid_require_be and not basket.all_at_be:
            return False, "pyramid_needs_be"

        # Require primary is protected (net PnL > 0)
        if not basket.primary_protected:
            return False, "pyramid_primary_not_protected"

        # Require structural advance: price moved min ATR from avg entry
        if signal.side == Side.BUY:
            advance = signal.entry_price - basket.avg_entry
        else:
            advance = basket.avg_entry - signal.entry_price
        min_advance = ctx_atr * self.cfg.pyramid_min_advance_atr
        if advance < min_advance:
            return False, f"pyramid_no_advance({advance:.2f}<{min_advance:.2f})"

        # Basket PnL must be positive
        if basket.net_pnl <= 0:
            return False, f"pyramid_basket_negative({basket.net_pnl:.2f})"

        return True, "OK"

    # ═════════════════════════════════════════════════════════
    #  TRIPLE MONETARY VALIDATION + SIZING
    # ═════════════════════════════════════════════════════════

    def size_and_verify(self, spec: SymbolSpec, signal: Signal,
                        is_add: bool = False) -> RiskVerification:
        """
        Calculate volume, then triple-verify the monetary risk.
        Returns RiskVerification with final_risk_usd and volume in signal.
        If verification fails → passed=False, reject_reason set.
        """
        equity = MT5.equity()
        if equity <= 0:
            return RiskVerification(passed=False, reject_reason="zero_equity")

        # Base risk budget
        risk_pct = self.cfg.risk_pct
        if is_add:
            risk_pct *= (self.cfg.pyramid_size_pct / 100.0)
        risk_budget = equity * risk_pct / 100.0

        # Absolute cap
        abs_cap = self.cfg.abs_max_risk(spec.requested)
        risk_budget = min(risk_budget, abs_cap)

        entry = signal.entry_price
        sl = signal.sl_price
        side = signal.side

        # ── Calculate volume ─────────────────────────────
        volume = self._calc_volume(spec, side, entry, sl, risk_budget)

        # ── Absolute volume clamp ────────────────────────
        vol_cap = self.cfg.abs_max_vol(spec.requested)
        volume = min(volume, vol_cap)
        volume = max(volume, spec.volume_min)
        volume = self._normalize_vol(spec, volume)

        # ── Triple verification ──────────────────────────
        v = RiskVerification()

        # Method 1: Broker calc
        action = MT5.ORDER_BUY() if side == Side.BUY else MT5.ORDER_SELL()
        calc = MT5.order_calc_profit(action, spec.actual, volume, entry, sl)
        if calc is not None:
            v.broker_calc_usd = abs(float(calc))

        # Method 2: Tick math
        v.tick_math_usd = self._tick_math(spec, volume, entry, sl)

        # Method 3: Contract math
        v.contract_math_usd = self._contract_math(spec, volume, entry, sl)

        # ── Pick final value ─────────────────────────────
        values = []
        labels = []
        if v.broker_calc_usd is not None and v.broker_calc_usd > 0:
            values.append(v.broker_calc_usd)
            labels.append("broker")
        if v.tick_math_usd is not None and v.tick_math_usd > 0:
            values.append(v.tick_math_usd)
            labels.append("tick")
        if v.contract_math_usd is not None and v.contract_math_usd > 0:
            values.append(v.contract_math_usd)
            labels.append("contract")

        if not values:
            v.passed = False
            v.reject_reason = "no_valid_risk_calc"
            return v

        # ── Discrepancy check ────────────────────────────
        if len(values) >= 2:
            hi = max(values)
            lo = min(values)
            ratio = hi / max(lo, 1e-10)
            v.discrepancy_ratio = ratio
            if ratio > self.cfg.max_risk_discrepancy:
                v.passed = False
                v.reject_reason = (
                    f"risk_discrepancy({ratio:.1f}x>{self.cfg.max_risk_discrepancy}x) "
                    f"vals={dict(zip(labels, [f'${x:.2f}' for x in values]))}"
                )
                log.warning(f"[RISK] BLOCKED {spec.actual}: {v.reject_reason}")
                return v

        # Use broker if available & consistent, else median
        if v.broker_calc_usd and len(values) >= 2:
            v.final_risk_usd = v.broker_calc_usd
            v.method_used = "broker"
        elif len(values) >= 2:
            values.sort()
            v.final_risk_usd = values[len(values) // 2]
            v.method_used = "median"
        else:
            v.final_risk_usd = values[0]
            v.method_used = labels[0]

        # ── Final budget check: iteratively reduce volume ─
        attempts = 0
        while v.final_risk_usd > risk_budget * 1.10 and volume > spec.volume_min and attempts < 20:
            volume = max(spec.volume_min, self._normalize_vol(spec, volume - spec.volume_step))
            v.final_risk_usd = self._best_estimate(spec, side, volume, entry, sl)
            attempts += 1

        # ── Absolute risk cap ────────────────────────────
        if v.final_risk_usd > abs_cap:
            v.passed = False
            v.reject_reason = f"exceeds_abs_cap(${v.final_risk_usd:.2f}>${abs_cap:.2f})"
            return v

        v.passed = True
        v.volume_final = volume
        signal.entry_price = entry
        log.info(
            f"[RISK] {spec.actual} {side.value} vol={volume:.4f} "
            f"risk=${v.final_risk_usd:.2f}/{risk_budget:.2f} "
            f"method={v.method_used} disc={v.discrepancy_ratio:.2f}x "
            f"broker=${v.broker_calc_usd or 0:.2f} tick=${v.tick_math_usd or 0:.2f} "
            f"contract=${v.contract_math_usd or 0:.2f}"
        )
        return v

    # ═════════════════════════════════════════════════════════
    #  BASKET STATE BUILDER
    # ═════════════════════════════════════════════════════════

    def build_basket(self, spec: SymbolSpec, side: Side,
                     trades: dict,
                     peaks: Optional[dict] = None) -> BasketState:
        """Build basket state from current positions + trade records.
        peaks: pass PositionManager.basket_peaks for accurate historical peak_pnl."""
        positions = MT5.positions_get(symbol=spec.actual)
        b = BasketState(symbol=spec.actual, side=side)
        total_vol_price = 0.0
        all_be = True

        for pos in (positions or []):
            p_side = Side.BUY if int(pos.type) == 0 else Side.SELL
            if p_side != side:
                continue
            ticket = int(pos.ticket)
            b.tickets.append(ticket)
            b.total_volume += float(pos.volume)
            b.net_pnl += float(pos.profit)
            total_vol_price += float(pos.volume) * float(pos.price_open)
            b.count += 1

            rec = trades.get(ticket)
            if rec:
                b.total_risk_usd += rec.risk_usd
                if not rec.be_done:
                    all_be = False
                if rec.is_add is False and rec.be_done and float(pos.profit) > 0:
                    b.primary_protected = True
            else:
                all_be = False

        if b.total_volume > 0:
            b.avg_entry = total_vol_price / b.total_volume
        b.all_protected = all_be and b.count > 0
        if peaks is not None:
            key = f"{spec.actual}:{side.value}"
            b.peak_pnl = max(peaks.get(key, 0.0), b.net_pnl)
        else:
            b.peak_pnl = max(b.peak_pnl, b.net_pnl)
        return b

    # ═════════════════════════════════════════════════════════
    #  SESSION FILTER
    # ═════════════════════════════════════════════════════════

    def session_allowed(self) -> Tuple[bool, str]:
        if not self.cfg.sessions_enabled:
            return True, "sessions_disabled"
        hour = datetime.now(timezone.utc).hour
        london = self.cfg.london_start <= hour < self.cfg.london_end
        ny = self.cfg.ny_start <= hour < self.cfg.ny_end
        a_start, a_end = self.cfg.asian_start, self.cfg.asian_end
        asian = hour >= a_start or hour < a_end
        overlap = london and ny
        if self.cfg.prefer_overlap and overlap:
            return True, "overlap"
        if london: return True, "london"
        if ny: return True, "ny"
        if asian: return True, "asian"
        return False, f"off_session(h={hour})"

    # ── Tracking ─────────────────────────────────────────────

    def record_open(self) -> None: self.daily.trades_opened += 1
    def record_close(self, pnl: float) -> None:
        self.daily.trades_closed += 1
        if pnl >= 0:
            self.daily.wins += 1; self.daily.gross_profit += pnl
        else:
            self.daily.losses += 1; self.daily.gross_loss += abs(pnl)

    # ═════════════════════════════════════════════════════════
    #  INTERNAL: SIZING CALCULATIONS
    # ═════════════════════════════════════════════════════════

    def _calc_volume(self, spec: SymbolSpec, side: Side,
                     entry: float, sl: float, risk_budget: float) -> float:
        """Calculate volume from risk budget."""
        # Try broker calc first
        probe = max(spec.volume_min, 0.01)
        action = MT5.ORDER_BUY() if side == Side.BUY else MT5.ORDER_SELL()
        calc = MT5.order_calc_profit(action, spec.actual, probe, entry, sl)
        if calc is not None:
            loss_per_probe = abs(float(calc))
            if loss_per_probe > 0:
                raw = risk_budget / loss_per_probe * probe
                return self._normalize_vol(spec, raw)

        # Tick math
        loss_per_probe = self._tick_math(spec, probe, entry, sl)
        if loss_per_probe > 0:
            raw = risk_budget / loss_per_probe * probe
            return self._normalize_vol(spec, raw)

        # Contract math
        loss_per_probe = self._contract_math(spec, probe, entry, sl)
        if loss_per_probe > 0:
            raw = risk_budget / loss_per_probe * probe
            return self._normalize_vol(spec, raw)

        return spec.volume_min

    def _best_estimate(self, spec: SymbolSpec, side: Side,
                       volume: float, entry: float, sl: float) -> float:
        """Best available risk estimate for a given volume."""
        action = MT5.ORDER_BUY() if side == Side.BUY else MT5.ORDER_SELL()
        calc = MT5.order_calc_profit(action, spec.actual, volume, entry, sl)
        if calc is not None:
            return abs(float(calc))
        tm = self._tick_math(spec, volume, entry, sl)
        if tm > 0: return tm
        cm = self._contract_math(spec, volume, entry, sl)
        if cm > 0: return cm
        return 0.0

    def _tick_math(self, spec: SymbolSpec, volume: float,
                   entry: float, sl: float) -> float:
        dist = abs(entry - sl)
        ts = spec.tick_size or spec.point or 0.01
        tv = spec.tick_value
        if tv <= 0 or ts <= 0:
            return 0.0
        return abs(dist / ts * tv * volume)

    def _contract_math(self, spec: SymbolSpec, volume: float,
                       entry: float, sl: float) -> float:
        """Calculate using contract_size directly.
        For XAU: 1 lot = 100 oz, $1 move = $100.
        dist_points × point_value_per_lot × volume
        point_value_per_lot = contract_size × point (for direct quote to USD)
        """
        dist = abs(entry - sl)
        point = spec.point
        if point <= 0:
            return 0.0
        dist_points = dist / point
        # For USD-denominated pairs, 1 point move on 1 lot = contract_size × point
        # For XAU: 100 × 0.01 = $1 per point per lot → $1 × dist_points × volume
        pv = spec.contract_size * point
        if pv <= 0:
            return 0.0
        return abs(dist_points * pv * volume)

    def _normalize_vol(self, spec: SymbolSpec, raw: float) -> float:
        step = spec.volume_step or 0.01
        vol = max(spec.volume_min, min(spec.volume_max, raw))
        steps = int((vol - spec.volume_min) / step)
        return round(spec.volume_min + max(0, steps) * step, 8)

    def _daily_dd_pct(self) -> float:
        if self.daily.start_equity <= 0: return 0.0
        return max(0.0, (self.daily.start_equity - self.daily.current_equity) / self.daily.start_equity * 100)

    def _total_dd_pct(self) -> float:
        b, e = MT5.balance(), MT5.equity()
        if b <= 0: return 0.0
        return max(0.0, (b - e) / b * 100)

    @staticmethod
    def _today() -> str:
        return datetime.now(timezone.utc).strftime("%Y-%m-%d")
