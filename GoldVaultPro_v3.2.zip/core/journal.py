"""
GoldVault Pro v2.1 — Trade Journal + Learning Engine (Prioridad 5)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
• Log estructurado por trade con todos los datos del contexto
• Ranking por setup (qué estrategia + régimen funciona mejor)
• Ajuste automático de thresholds por desempeño
• Base SQLite consultable
• Telegram opcional
"""
from __future__ import annotations
import json
import logging
import sqlite3
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional

from .config import Config

log = logging.getLogger("gvpro.journal")
DB_PATH = Path("state") / "goldvault_journal.sqlite3"


class Journal:
    def __init__(self, cfg: Config):
        self.cfg = cfg
        self._init_db()

    def _conn(self) -> sqlite3.Connection:
        return sqlite3.connect(DB_PATH)

    def _init_db(self) -> None:
        DB_PATH.parent.mkdir(parents=True, exist_ok=True)
        with self._conn() as c:
            c.execute("""CREATE TABLE IF NOT EXISTS trades (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ts REAL, event TEXT, ticket INTEGER,
                symbol TEXT, side TEXT, setup TEXT,
                volume REAL, entry_price REAL, sl REAL, tp REAL,
                risk_usd REAL, risk_method TEXT,
                score REAL, rr_ratio REAL,
                regime TEXT, adx REAL, rsi REAL, atr REAL, zscore REAL,
                spread_pct REAL,
                pnl REAL, reason TEXT, reasons_json TEXT,
                hold_seconds REAL,
                profile TEXT, session TEXT,
                peak_profit REAL, partials_taken INTEGER,
                is_add INTEGER DEFAULT 0
            )""")
            c.execute("""CREATE TABLE IF NOT EXISTS daily_stats (
                date TEXT PRIMARY KEY,
                profile TEXT, start_equity REAL, end_equity REAL,
                opened INTEGER, closed INTEGER, wins INTEGER, losses INTEGER,
                gross_profit REAL, gross_loss REAL, net_pnl REAL,
                max_dd_pct REAL, win_rate REAL, profit_factor REAL
            )""")
            c.execute("""CREATE TABLE IF NOT EXISTS setup_performance (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                updated_ts REAL,
                symbol TEXT, setup TEXT, regime TEXT,
                total_trades INTEGER, wins INTEGER, losses INTEGER,
                win_rate REAL, avg_pnl REAL, avg_rr REAL,
                profit_factor REAL,
                suggested_min_score REAL,
                suggested_min_rr REAL
            )""")
            c.execute("CREATE INDEX IF NOT EXISTS idx_trades_ts ON trades(ts)")
            c.execute("CREATE INDEX IF NOT EXISTS idx_trades_setup ON trades(setup, regime)")

    # ═════════════════════════════════════════════════════════
    #  TRADE EVENTS
    # ═════════════════════════════════════════════════════════

    def log_open(self, *, ticket: int, symbol: str, side: str, setup: str,
                 volume: float, entry: float, sl: float, tp: float,
                 risk_usd: float, risk_method: str, score: float, rr: float,
                 regime: str, adx: float, rsi: float, atr: float,
                 zscore: float = 0, spread_pct: float = 0,
                 reasons: list = None, is_add: bool = False) -> None:
        try:
            with self._conn() as c:
                c.execute("""INSERT INTO trades(
                    ts,event,ticket,symbol,side,setup,volume,entry_price,sl,tp,
                    risk_usd,risk_method,score,rr_ratio,regime,adx,rsi,atr,zscore,
                    spread_pct,reasons_json,profile,is_add
                ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (time.time(), "OPEN", ticket, symbol, side, setup, volume,
                 entry, sl, tp, risk_usd, risk_method, score, rr,
                 regime, adx, rsi, atr, zscore, spread_pct,
                 json.dumps(reasons or []),
                 self.cfg.profile_name, int(is_add)))
        except Exception as e:
            log.error(f"Journal log_open: {e}")

        self._notify(
            f"{'🔺' if is_add else '🟢'} {'ADD' if is_add else 'OPEN'} {setup}\n"
            f"{symbol} {side} vol={volume:.4f}\n"
            f"Entry={entry:.2f} SL={sl:.2f} TP={tp:.2f}\n"
            f"Risk=${risk_usd:.2f} RR={rr:.1f} Score={score:.0f}\n"
            f"{regime} ADX={adx:.0f} RSI={rsi:.0f}\n"
            f"{', '.join(reasons or [])}"
        )

    def log_close(self, *, ticket: int, symbol: str, pnl: float,
                  reason: str, hold_seconds: float = 0,
                  peak_profit: float = 0, partials: int = 0) -> None:
        try:
            with self._conn() as c:
                c.execute("""INSERT INTO trades(
                    ts,event,ticket,symbol,pnl,reason,hold_seconds,
                    peak_profit,partials_taken,profile
                ) VALUES(?,?,?,?,?,?,?,?,?,?)""",
                (time.time(), "CLOSE", ticket, symbol, pnl, reason,
                 hold_seconds, peak_profit, partials, self.cfg.profile_name))
        except Exception as e:
            log.error(f"Journal log_close: {e}")

        emoji = "🟢" if pnl >= 0 else "🔴"
        self._notify(f"{emoji} CLOSE {symbol} ${pnl:+.2f} | {reason}")

    # ═════════════════════════════════════════════════════════
    #  DAILY STATS
    # ═════════════════════════════════════════════════════════

    def save_daily(self, date: str, start_eq: float, end_eq: float,
                   opened: int, closed: int, wins: int, losses: int,
                   profit: float, loss: float, dd: float) -> None:
        net = profit - loss
        wr = wins / max(closed, 1) * 100
        pf = profit / max(loss, 0.01)
        try:
            with self._conn() as c:
                c.execute("""INSERT OR REPLACE INTO daily_stats VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                    (date, self.cfg.profile_name, start_eq, end_eq,
                     opened, closed, wins, losses, profit, loss, net, dd, wr, pf))
        except Exception as e:
            log.error(f"Journal save_daily: {e}")

    # ═════════════════════════════════════════════════════════
    #  SETUP RANKING (Prioridad 5)
    # ═════════════════════════════════════════════════════════

    def update_setup_rankings(self) -> Dict[str, dict]:
        """
        Analyze closed trades by setup+regime, compute win rates and P/F.
        Suggests threshold adjustments based on performance.
        Returns dict of {setup:regime -> stats}.
        """
        results = {}
        try:
            with self._conn() as c:
                # Get all OPEN trades with their corresponding CLOSE
                rows = c.execute("""
                    SELECT o.setup, o.regime, o.symbol,
                           o.score, o.rr_ratio,
                           cl.pnl
                    FROM trades o
                    INNER JOIN trades cl ON cl.ticket = o.ticket AND cl.event = 'CLOSE'
                    WHERE o.event = 'OPEN'
                    AND o.ts > ?
                    ORDER BY o.setup, o.regime
                """, (time.time() - 30 * 86400,)).fetchall()

                # Group by setup:regime
                groups: Dict[str, list] = {}
                for setup, regime, symbol, score, rr, pnl in rows:
                    key = f"{setup}:{regime}"
                    if key not in groups:
                        groups[key] = []
                    groups[key].append({
                        "score": score or 0, "rr": rr or 0,
                        "pnl": pnl or 0, "symbol": symbol,
                    })

                for key, trades in groups.items():
                    setup, regime = key.split(":")
                    total = len(trades)
                    wins = sum(1 for t in trades if t["pnl"] > 0)
                    losses = total - wins
                    wr = wins / max(total, 1) * 100
                    avg_pnl = sum(t["pnl"] for t in trades) / max(total, 1)
                    avg_rr = sum(t["rr"] for t in trades) / max(total, 1)
                    gp = sum(t["pnl"] for t in trades if t["pnl"] > 0)
                    gl = abs(sum(t["pnl"] for t in trades if t["pnl"] < 0))
                    pf = gp / max(gl, 0.01)

                    # Suggest threshold adjustments
                    # If win rate < 40%, suggest raising min_score
                    win_scores = [t["score"] for t in trades if t["pnl"] > 0]
                    loss_scores = [t["score"] for t in trades if t["pnl"] <= 0]
                    sugg_score = (
                        sum(win_scores) / len(win_scores) * 0.8
                        if win_scores else 50
                    )
                    sugg_rr = avg_rr * 1.1 if wr < 45 else avg_rr

                    stats = {
                        "total": total, "wins": wins, "losses": losses,
                        "win_rate": wr, "avg_pnl": avg_pnl, "avg_rr": avg_rr,
                        "profit_factor": pf,
                        "suggested_min_score": round(sugg_score, 1),
                        "suggested_min_rr": round(sugg_rr, 2),
                    }
                    results[key] = stats

                    # Save to DB
                    c.execute("""INSERT INTO setup_performance(
                        updated_ts, symbol, setup, regime,
                        total_trades, wins, losses, win_rate,
                        avg_pnl, avg_rr, profit_factor,
                        suggested_min_score, suggested_min_rr
                    ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                    (time.time(), "", setup, regime, total, wins, losses,
                     wr, avg_pnl, avg_rr, pf, sugg_score, sugg_rr))

        except Exception as e:
            log.error(f"Journal update_rankings: {e}")

        if results:
            log.info("[LEARN] Setup rankings updated:")
            for key, s in results.items():
                log.info(
                    f"  {key}: {s['total']} trades, WR={s['win_rate']:.0f}%, "
                    f"PF={s['profit_factor']:.2f}, "
                    f"sugg_score>={s['suggested_min_score']}, "
                    f"sugg_rr>={s['suggested_min_rr']}"
                )
        return results

    # ═════════════════════════════════════════════════════════
    #  ANALYTICS
    # ═════════════════════════════════════════════════════════

    def get_stats(self, days: int = 30) -> dict:
        try:
            with self._conn() as c:
                row = c.execute("""
                    SELECT COUNT(*),
                           SUM(CASE WHEN pnl>0 THEN 1 ELSE 0 END),
                           SUM(CASE WHEN pnl>0 THEN pnl ELSE 0 END),
                           SUM(CASE WHEN pnl<0 THEN pnl ELSE 0 END)
                    FROM trades WHERE event='CLOSE' AND ts > ?
                """, (time.time() - days * 86400,)).fetchone()
                if row:
                    t, w, p, l = row
                    t = t or 0; w = w or 0; p = p or 0; l = l or 0
                    return {
                        "total": t, "wins": w, "losses": t - w,
                        "win_rate": w / max(t, 1) * 100,
                        "gross_profit": p, "gross_loss": abs(l),
                        "net": p + l,
                        "profit_factor": p / max(abs(l), 0.01),
                    }
        except Exception:
            pass
        return {}

    # ── Telegram ─────────────────────────────────────────────

    def _notify(self, message: str) -> None:
        if not self.cfg.tg_enabled:
            return
        try:
            import requests
            requests.post(
                f"https://api.telegram.org/bot{self.cfg.tg_token}/sendMessage",
                json={"chat_id": self.cfg.tg_chat, "text": message},
                timeout=5,
            )
        except Exception:
            pass
