"""
GoldVault Pro — Technical Indicators
Pure-Python implementations optimized for real-time calculation.
Uses numpy for performance where available.
"""
from __future__ import annotations
import math
from typing import List, Tuple

try:
    import numpy as np
    HAS_NP = True
except ImportError:
    np = None  # type: ignore
    HAS_NP = False


# ═════════════════════════════════════════════════════════════
#  MOVING AVERAGES
# ═════════════════════════════════════════════════════════════

def ema(values: List[float], period: int) -> float:
    """Exponential Moving Average — returns last value."""
    if not values or period < 1:
        return 0.0
    k = 2.0 / (period + 1)
    result = values[0]
    for v in values[1:]:
        result = v * k + result * (1.0 - k)
    return result


def ema_series(values: List[float], period: int) -> List[float]:
    """Full EMA series for historical lookback."""
    if not values or period < 1:
        return []
    k = 2.0 / (period + 1)
    out = [values[0]]
    for v in values[1:]:
        out.append(v * k + out[-1] * (1.0 - k))
    return out


def sma(values: List[float], period: int) -> float:
    """Simple Moving Average — last value."""
    if len(values) < period:
        return values[-1] if values else 0.0
    return sum(values[-period:]) / period


# ═════════════════════════════════════════════════════════════
#  RSI (Wilder's smoothing)
# ═════════════════════════════════════════════════════════════

def rsi(closes: List[float], period: int = 14) -> float:
    """RSI with Wilder's smoothed average."""
    if len(closes) <= period:
        return 50.0

    deltas = [closes[i] - closes[i - 1] for i in range(1, len(closes))]

    # Seed with SMA
    gains = [max(d, 0.0) for d in deltas[:period]]
    losses = [abs(min(d, 0.0)) for d in deltas[:period]]
    avg_gain = sum(gains) / period
    avg_loss = sum(losses) / period

    # Wilder smoothing for remaining
    for d in deltas[period:]:
        g = max(d, 0.0)
        l = abs(min(d, 0.0))
        avg_gain = (avg_gain * (period - 1) + g) / period
        avg_loss = (avg_loss * (period - 1) + l) / period

    if avg_loss < 1e-10:
        return 100.0
    rs = avg_gain / avg_loss
    return 100.0 - (100.0 / (1.0 + rs))


# ═════════════════════════════════════════════════════════════
#  ADX (proper Wilder's with +DI/-DI)
# ═════════════════════════════════════════════════════════════

def adx(highs: List[float], lows: List[float], closes: List[float],
        period: int = 14) -> Tuple[float, float, float]:
    """Returns (ADX, +DI, -DI) using proper Wilder's smoothing."""
    n = len(closes)
    if n < period + 2:
        return 15.0, 0.0, 0.0

    # True Range, +DM, -DM
    tr_list, pdm_list, ndm_list = [], [], []
    for i in range(1, n):
        hl = highs[i] - lows[i]
        hc = abs(highs[i] - closes[i - 1])
        lc = abs(lows[i] - closes[i - 1])
        tr_list.append(max(hl, hc, lc))
        up = highs[i] - highs[i - 1]
        dn = lows[i - 1] - lows[i]
        pdm_list.append(up if up > dn and up > 0 else 0.0)
        ndm_list.append(dn if dn > up and dn > 0 else 0.0)

    # Wilder's smoothed sums
    atr_s = sum(tr_list[:period])
    pdm_s = sum(pdm_list[:period])
    ndm_s = sum(ndm_list[:period])

    dx_values = []
    for i in range(period, len(tr_list)):
        atr_s = atr_s - atr_s / period + tr_list[i]
        pdm_s = pdm_s - pdm_s / period + pdm_list[i]
        ndm_s = ndm_s - ndm_s / period + ndm_list[i]

        pdi = 100.0 * pdm_s / max(atr_s, 1e-10)
        ndi = 100.0 * ndm_s / max(atr_s, 1e-10)
        dsum = pdi + ndi
        dx = abs(pdi - ndi) / max(dsum, 1e-10) * 100.0 if dsum > 0 else 0.0
        dx_values.append((dx, pdi, ndi))

    if not dx_values:
        return 15.0, 0.0, 0.0

    # ADX = Wilder's EMA of DX
    adx_val = dx_values[0][0] if len(dx_values) < period else sum(d[0] for d in dx_values[:period]) / period
    for i in range(period, len(dx_values)):
        adx_val = (adx_val * (period - 1) + dx_values[i][0]) / period

    last = dx_values[-1]
    return adx_val, last[1], last[2]


# ═════════════════════════════════════════════════════════════
#  MACD
# ═════════════════════════════════════════════════════════════

def macd(closes: List[float], fast: int = 12, slow: int = 26,
         signal: int = 9) -> Tuple[float, float, float]:
    """Returns (MACD line, Signal line, Histogram)."""
    if len(closes) < slow + signal:
        return 0.0, 0.0, 0.0

    fast_ema = ema_series(closes, fast)
    slow_ema = ema_series(closes, slow)
    macd_line = [f - s for f, s in zip(fast_ema, slow_ema)]
    signal_line = ema_series(macd_line, signal)

    m = macd_line[-1]
    s = signal_line[-1]
    return m, s, m - s


# ═════════════════════════════════════════════════════════════
#  ATR
# ═════════════════════════════════════════════════════════════

def atr(highs: List[float], lows: List[float], closes: List[float],
        period: int = 14) -> float:
    """Average True Range using Wilder's smoothing."""
    if len(closes) <= 1:
        return max(0.0, (highs[-1] - lows[-1]) if highs and lows else 0.0)

    trs = []
    for i in range(1, len(closes)):
        hl = highs[i] - lows[i]
        hc = abs(highs[i] - closes[i - 1])
        lc = abs(lows[i] - closes[i - 1])
        trs.append(max(hl, hc, lc))

    if len(trs) < period:
        return sum(trs) / len(trs) if trs else 0.0

    # Wilder smoothing
    atr_val = sum(trs[:period]) / period
    for tr in trs[period:]:
        atr_val = (atr_val * (period - 1) + tr) / period
    return atr_val


# ═════════════════════════════════════════════════════════════
#  BOLLINGER BANDS
# ═════════════════════════════════════════════════════════════

def bollinger(closes: List[float], period: int = 20,
              std_mult: float = 2.0) -> Tuple[float, float, float]:
    """Returns (upper, middle, lower)."""
    if len(closes) < period:
        mid = closes[-1] if closes else 0.0
        return mid, mid, mid

    window = closes[-period:]
    mid = sum(window) / period
    variance = sum((x - mid) ** 2 for x in window) / period
    std = math.sqrt(variance) if variance > 0 else 0.0

    return mid + std_mult * std, mid, mid - std_mult * std


# ═════════════════════════════════════════════════════════════
#  DONCHIAN CHANNELS
# ═════════════════════════════════════════════════════════════

def donchian(highs: List[float], lows: List[float],
             period: int = 55) -> Tuple[float, float]:
    """Returns (highest high, lowest low) of the last `period` bars (excluding current)."""
    if len(highs) < 2:
        return highs[-1] if highs else 0.0, lows[-1] if lows else 0.0

    h_window = highs[-period - 1:-1] if len(highs) > period else highs[:-1]
    l_window = lows[-period - 1:-1] if len(lows) > period else lows[:-1]

    return max(h_window) if h_window else highs[-1], min(l_window) if l_window else lows[-1]


# ═════════════════════════════════════════════════════════════
#  Z-SCORE
# ═════════════════════════════════════════════════════════════

def zscore(values: List[float], period: int = 20) -> float:
    """Standard z-score of the last value relative to the window."""
    if len(values) < period:
        return 0.0
    window = values[-period:]
    mu = sum(window) / len(window)
    var = sum((x - mu) ** 2 for x in window) / len(window)
    sd = math.sqrt(var) if var > 0 else 0.0
    return (values[-1] - mu) / sd if sd > 0 else 0.0


# ═════════════════════════════════════════════════════════════
#  VOLUME (relative)
# ═════════════════════════════════════════════════════════════

def volume_ratio(volumes: List[float], period: int = 20) -> float:
    """Current volume / SMA(volume) — above 1.0 = above-average."""
    if len(volumes) < period or not volumes:
        return 1.0
    avg = sum(volumes[-period:]) / period
    return volumes[-1] / max(avg, 1e-10)


# ═════════════════════════════════════════════════════════════
#  MOMENTUM & COMPRESSION
# ═════════════════════════════════════════════════════════════

def momentum(closes: List[float], atr_val: float, lookback: int = 3) -> float:
    """Net price displacement over last N bars normalized by ATR.
    Positive = bullish momentum, Negative = bearish momentum.
    Values > 0.4 indicate strong directional acceleration."""
    if len(closes) < lookback + 1 or atr_val <= 0:
        return 0.0
    net = closes[-1] - closes[-1 - lookback]
    return net / atr_val


def compression_ratio(highs: List[float], lows: List[float],
                      closes: List[float],
                      short_period: int = 5, long_period: int = 20) -> float:
    """Ratio of recent ATR to longer-period ATR.
    < 0.7 = strong compression (coiling for breakout)
    > 1.3 = expansion (trend / volatility burst)"""
    if len(closes) < long_period + 1:
        return 1.0
    atr_short = atr(highs[-short_period - 1:], lows[-short_period - 1:],
                    closes[-short_period - 1:], min(short_period, len(closes) - 1))
    atr_long = atr(highs[-long_period - 1:], lows[-long_period - 1:],
                   closes[-long_period - 1:], min(long_period, len(closes) - 1))
    if atr_long <= 0:
        return 1.0
    return atr_short / atr_long
