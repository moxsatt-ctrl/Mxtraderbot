# AUDITORÍA COMPLETA — GoldVault IA → GoldVault Pro v2.0

## Resumen Ejecutivo

Se realizó una auditoría exhaustiva del código de GoldVault IA (mxv3). Se identificaron **23 problemas críticos y de diseño** que causaban pérdidas, bloqueos innecesarios y riesgos monetarios descontrolados. El bot fue **reescrito completamente desde cero** como GoldVault Pro v2.0, un gestor de inversión profesional compatible con todos los brokers MT5.

---

## PROBLEMAS ENCONTRADOS EN EL BOT ORIGINAL

### 🔴 CRÍTICOS (Causan pérdidas directas)

**1. Cálculo de riesgo monetario defectuoso**
- **Archivo:** `risk.py`, líneas 28-45
- **Problema:** La función `estimate_loss_usd()` usa `tick_value` crudo sin validación robusta. Cuando el broker retorna valores inflados para CFDs, el bot abre posiciones con riesgo de $378-$636 en lugar de $1-$3.
- **Impacto:** Pérdidas de -$126, -$170, -$184 documentadas en logs.
- **Solución v2:** Sistema de 3 capas: (1) `order_calc_profit` del broker, (2) tick-math como verificación cruzada, (3) fallback conservador. Si la diferencia entre métodos es >5x, descarta el valor del broker.

**2. Sin límite de drawdown diario (kill switch)**
- **Archivo:** No existía
- **Problema:** El bot no tiene circuit breaker. Si pierde 10%, 20%, 50% en un día, sigue operando.
- **Impacto:** Riesgo de destrucción total de la cuenta en días volátiles.
- **Solución v2:** Circuit breaker con drawdown diario (3%) y total (8%). Se detiene automáticamente.

**3. Sizing basado en USD fijo, no en % de equity**
- **Archivo:** `config.py` → `xau_risk_usd=1.10`, `btc_risk_usd=3.0`
- **Problema:** Riesgo en USD fijo no escala con la cuenta. $1.10 en una cuenta de $100 es 1.1%, pero en $10,000 es 0.011%.
- **Impacto:** Ineficiente en cuentas grandes, destructivo en cuentas pequeñas.
- **Solución v2:** Riesgo como % del equity actual (default 1%).

**4. Position Manager cierra trades ganadores prematuramente**
- **Archivo:** `position_manager.py`, línea 37
- **Problema:** `WINNER_REVERSED` cierra si peak >= $1.60 y current <= -$0.18. En XAUUSD con spread de $0.30-0.50, esto cierra ganadores que simplemente retroceden al spread.
- **Impacto:** Trades que serían ganadores de $8-15 se cierran a -$0.18.
- **Solución v2:** Sistema de 6 capas basado en ATR: breakeven → partial TP1 (50% a 1.5R) → partial TP2 (30% a 2.5R) → trailing ATR en el 20% restante → giveback protection.

**5. Stop loss demasiado ajustado en scalp**
- **Archivo:** `main_v3.py`, línea 85
- **Problema:** `stop_points = max(stops_level + 8, int(round(atr_points * 0.60)), 32)` — 0.60 × ATR es insuficiente para XAUUSD que se mueve 2-3x ATR en correcciones normales.
- **Impacto:** Stop-outs constantes antes de que el trade tenga oportunidad de funcionar.
- **Solución v2:** SL = 1.5× ATR para scalp, 2.0× ATR para trend (respaldado por mejores prácticas de trading de oro que recomiendan 2× ATR como mínimo).

### 🟡 IMPORTANTES (Reducen rentabilidad)

**6. Sin filtro de sesión de trading**
- **Problema:** Opera 24/5 incluyendo sesión asiática donde XAUUSD tiene spreads altos y movimientos erráticos.
- **Solución v2:** Filtro de sesión London + NY con preferencia por overlap (12-16 UTC).

**7. Indicadores mal calculados**
- **Archivo:** `indicators.py`
- **Problema:** RSI usa SMA simple en vez de suavizado Wilder. ADX (`adx_rough`) usa SMA en vez de Wilder smoothing. Ambos dan lecturas incorrectas.
- **Solución v2:** RSI y ADX con suavizado Wilder correcto. ADX retorna +DI/-DI para confirmar dirección.

**8. Sin análisis multi-timeframe real**
- **Archivo:** `main_v3.py` → `_snapshot()` solo usa M15
- **Problema:** Todo el análisis se hace en un solo timeframe (M15). No hay confirmación de H1 ni H4.
- **Solución v2:** Tres timeframes: Entry (M15), Trend (H1), Bias (H4) con indicadores independientes y confluencia.

**9. Opportunity Engine con scores arbitrarios**
- **Archivo:** `opportunity_engine.py`
- **Problema:** Scores sumados sin peso normalizado. Un scalp puede acumular score=80+ y parecer mejor que un trend de score=40. No hay normalización por tipo de setup.
- **Solución v2:** Cada estrategia (Trend, Scalp, Breakout) se evalúa independientemente con condiciones específicas. Se selecciona la mejor señal por score.

**10. Director demasiado permisivo**
- **Archivo:** `director.py`
- **Problema:** Threshold de 24 para RANGE y 28 para TREND es muy bajo. Con los scores inflados del opportunity engine, casi cualquier condición pasa.
- **Solución v2:** Threshold mínimo de score=30 por estrategia + gate de RR ratio mínimo de 1.2.

**11. Cooldowns fijos e insuficientes**
- **Archivo:** `config.py` → `xau_cooldown=22s`
- **Problema:** 22 segundos entre trades es demasiado poco para XAUUSD en M15. Permite abrir 2-3 trades en la misma vela.
- **Solución v2:** Cooldown base 60s entre trades del mismo símbolo, 120s después de una pérdida.

**12. Sin MACD ni Bollinger Bands**
- **Problema:** El bot original solo usa EMA, RSI, ADX, Z-score y Donchian. No tiene MACD (confirmación de momentum) ni Bollinger Bands (mean reversion en rangos).
- **Solución v2:** MACD completo (line + signal + histograma), Bollinger Bands para scalp.

**13. Sin confirmación de volumen**
- **Problema:** No se valida si hay volumen detrás del movimiento. Breakouts sin volumen son falsos breakouts.
- **Solución v2:** Volume ratio (current/SMA) como confirmación en breakouts.

### 🟠 ESTRUCTURALES (Diseño)

**14. Código monolítico en main_v3.py (242 líneas)**
- Toda la lógica de análisis, decisión, ejecución y gestión en un solo archivo.
- **Solución v2:** 11 módulos especializados con responsabilidades claras.

**15. Configuración triplicada (.env + JSON + YAML)**
- Tres archivos de configuración dicen cosas diferentes. ¿Cuál manda?
- **Solución v2:** Un solo `settings.yaml` como fuente de verdad.

**16. Sin reconexión automática a MT5**
- Si MT5 se desconecta, el bot muere silenciosamente.
- **Solución v2:** `MT5.ensure()` con reconexión automática.

**17. Journal solo registra, no consulta**
- No se pueden consultar estadísticas históricas.
- **Solución v2:** Métodos de consulta para win rate, profit factor, etc.

**18. Trade Memory no se usa**
- `trade_memory.py` existe pero nunca se importa en main.
- **Solución v2:** Eliminado. La funcionalidad está integrada en Journal y PositionManager.

**19. Hard stops en USD fijo sin relación al ATR**
- `xau_hard_stop_usd=0.95` es completamente arbitrario y no se adapta a la volatilidad.
- **Solución v2:** Todos los stops basados en ATR.

**20. Sin verificación de free margin antes de operar**
- Puede intentar abrir trades sin margen suficiente.
- **Solución v2:** Check de margin level mínimo (50%).

**21. Filling mode: retry excesivo con combinaciones innecesarias**
- `execution.py` prueba 12+ combinaciones (con/sin price × con/sin SLTP × 4 fills).
- **Solución v2:** Cache del filling mode que funciona por símbolo. Solo retry si falla.

**22. No detecta variantes de nombre de símbolo**
- Si el broker usa "XAUUSDm" o "GOLD." en vez de "XAUUSD", el bot no encuentra el símbolo.
- **Solución v2:** Auto-detección de variantes comunes por broker.

**23. Sin Telegram para monitoreo remoto**
- Para vender el bot, necesita notificaciones.
- **Solución v2:** Telegram integrado con notificaciones de apertura, cierre y resumen diario.

---

## ARQUITECTURA v2.0

```
GoldVaultPro/
├── main.py                 # Entry point
├── start.bat               # Windows launcher
├── requirements.txt        # Dependencies
├── config/
│   └── settings.yaml       # ÚNICA fuente de configuración
├── core/
│   ├── __init__.py
│   ├── config.py           # Loader de YAML tipado
│   ├── mt5.py              # Abstracción MT5 con reconexión
│   ├── symbols.py          # Resolver universal de símbolos
│   ├── indicators.py       # Indicadores técnicos (Wilder correcto)
│   ├── market.py           # Análisis multi-timeframe
│   ├── strategy.py         # Motor de estrategias (3 estrategias)
│   ├── risk.py             # Gestión de riesgo + circuit breakers
│   ├── execution.py        # Ejecución con fill cache
│   ├── position_manager.py # Gestión de posiciones (6 capas)
│   ├── journal.py          # Logging SQLite + Telegram
│   └── types.py            # Tipos de datos
├── state/
│   ├── goldvault_journal.sqlite3
│   └── goldvault.log
└── docs/
    └── AUDIT_REPORT.md     # Este documento
```

---

## MEJORAS CLAVE PARA VENTA COMERCIAL

| Feature | Original | Pro v2.0 |
|---------|----------|----------|
| Compatibilidad brokers | Parcial | Universal (auto-detect fills, symbols) |
| Risk management | USD fijo | % equity + circuit breakers |
| Análisis | Single TF | Multi-TF (M15 + H1 + H4) |
| Indicadores | 5 básicos | 9 con cálculo correcto (Wilder) |
| Estrategias | 1 monolítica | 3 independientes (Trend/Scalp/Breakout) |
| Exit system | 3 reglas fijas | 6 capas ATR-dinámicas |
| Sesiones | Sin filtro | London + NY + overlap |
| Logs | Básico | SQLite + Telegram |
| Configuración | 3 archivos | 1 YAML limpio |
| Reconexión | No | Automática |
| Kill switch | No | Drawdown diario + total |

---

## RECOMENDACIONES PARA PRODUCCIÓN

1. **Backtesting obligatorio** antes de ir live. Usar el Strategy Tester de MT5 con datos de al menos 2 años.
2. **Demo por 4-6 semanas** mínimo para validar en condiciones reales.
3. **VPS recomendado** cerca del servidor del broker (London o New York) para latencia <10ms.
4. **Monitoreo diario** vía Telegram y revisión semanal del journal SQLite.
5. **Ajustar parámetros** según el broker: spreads, comisiones y horarios varían.
